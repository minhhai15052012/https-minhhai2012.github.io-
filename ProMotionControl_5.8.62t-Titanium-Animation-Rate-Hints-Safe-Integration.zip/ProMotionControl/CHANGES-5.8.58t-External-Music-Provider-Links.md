# ProMotion Control 5.8.58t – External music providers

- Music page now distinguishes Apple Music control from third-party provider launch links.
- Added HTTPS Universal Link launch buttons for YouTube, Spotify, and Zing MP3.
- Clarified that iOS public APIs do not allow this app to read or directly control another app's private Now Playing session.
- Removed the misleading use of this app's own `MPNowPlayingInfoCenter` dictionary as a fallback for external-app metadata.
- Apple Music controls remain scoped to `MPMusicPlayerController.systemMusicPlayer`.
- Kept physical display-rate limits and iOS thermal/power protections; no unsupported overclock or system-wide input hooks are added.
- Updated build preflight to validate provider launch integration.

The source VERSION is 5.8.57t; the successful build script will increment and stamp 5.8.58t.
