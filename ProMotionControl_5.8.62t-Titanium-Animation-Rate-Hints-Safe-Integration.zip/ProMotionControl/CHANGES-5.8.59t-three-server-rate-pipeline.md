# ProMotion Control 5.8.59t — three-server Hz/FPS request pipeline

Source baseline: 5.8.58t. The Ubuntu build script stamps 5.8.59t only after a successful package build.

## Changes
- FREE now resolves `RefreshMode` / `CustomRefreshRate` and `FPSMode` / `CustomFPS` independently, then applies the selected Hz as the requested maximum and FPS as the preferred cadence.
- PREMIUM now receives its complete server options when starting its display scheduler and uses the same independent Hz/FPS resolver.
- ADMIN now resolves preset modes as well as custom values (previously it read only the custom fields), and passes maximum Hz plus preferred FPS through the Nexus/PowerRefresh/CorePerformance chain.
- The shared PowerRefresh engine now preserves a separate preferred rate instead of always preferring the maximum rate.
- Existing hardware maximum, Low Power Mode, thermal and charging safeguards remain authoritative. A selected value above the physical panel maximum remains a saved request, not a promise of actual refresh/FPS.
- Existing server profile separation and authorization behavior are unchanged.

## Scope / validation
- The current emergency-release Logos filter still restricts injection to the standalone ProMotion Control app. This change does not broaden hooks into games or unrelated apps.
- Source-level checks and shell syntax checks are required; a successful iOS/Theos package build and on-device validation have not yet been performed in this environment.
