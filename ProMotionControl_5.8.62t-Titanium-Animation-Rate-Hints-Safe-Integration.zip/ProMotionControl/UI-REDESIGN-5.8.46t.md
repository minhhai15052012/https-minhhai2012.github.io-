# ProMotionControl 5.8.46t — UI redesign and lifecycle hardening

## Visual refresh
- Replaced the dark blue palette with the approved black / neon-purple palette.
- Updated shared cards, dividers, buttons, chips, switches, navigation and tab bar colors.
- Rebuilt the Home hero header with the app icon, app name, version pill and tagline.
- Reorganized Home with a saved-configuration status card, live metric tiles, device/chip information and the existing quick-navigation cards.
- Preserved the five existing tabs: Trang chủ, Ứng dụng, Thông số, Giới thiệu, Cài đặt.
- Preserved the existing sub-pages, controls, preference keys, routes and user actions.
- Kept the optional light theme.

## Stability / lifecycle changes
- Dashboard hierarchy creation now checks for the main thread, loaded view and duplicate build before creating controls.
- Live label updates are dispatched to the main thread if called elsewhere.
- CADisplayLink callbacks reject stale links and stop updating when the dashboard is no longer visible.
- Metrics display link is invalidated on both viewWillDisappear and viewDidDisappear.
- Hardware metrics timer now starts only after the Chip/Stats page is visible and is invalidated when leaving it.
- The existing lazy five-tab root and recovery launch screen remain intact.

## Validation limits
- This is source-level hardening, not a guarantee of zero crashes.
- The app has not been run on a physical iPhone in this environment.
- Theos and the iPhoneOS SDK are not installed in this environment, so a .deb cannot be compiled here.
