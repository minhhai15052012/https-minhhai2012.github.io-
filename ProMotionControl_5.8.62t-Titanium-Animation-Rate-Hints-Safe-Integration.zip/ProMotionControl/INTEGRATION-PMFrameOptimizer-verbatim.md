# PMFrameOptimizer verbatim integration

- The user-provided Objective-C snippet is included unchanged in `Tweak.x`, including all three imports, declarations, method bodies, comments, 60–120 CAFrameRateRange request, legacy 60 FPS fallback, Common Modes registration, and stop/invalidate logic.
- It is currently compiled as a helper class but is not instantiated or started. The active `Tweak.x` deliberately has emergency runtime isolation: the filter is restricted to `com.dell.promotioncontrol.app`, and `PMRuntimeHooksAllowedForEmergencyRelease()` returns `NO`. This prevents claiming that the helper currently changes refresh behavior in third-party apps.
- The supplied `renderFrame:` callback is empty. A CADisplayLink request is advisory and is not a GPU optimizer, a hardware overclock, or a guarantee that another app renders at 120 FPS. The OS and device determine the rate actually delivered.
- No existing `Tweak.x` code was removed or rewritten for this integration. No global injection or private display-driver hooks were enabled.
- Validation in this environment is static only. The current container does not contain the user's Theos tree/iOS SDK, so a device-target Theos build and runtime test were not performed.
