ProMotion Control 5.8.61t — Adaptive thermal/load governor for FREE, PREMIUM and ADMIN

- Adds one shared hardware-aware thermal/load ceiling to all three server engines.
- While thermal state is Fair, FREE targets a conservative ceiling; PREMIUM and ADMIN use a higher but still reduced ceiling. Every request remains clamped to UIScreen.maximumFramesPerSecond.
- Charging guard and sustained frame misses further lower auxiliary render cadence.
- RSS monitoring now uses hysteresis to enable/clear auxiliary-work shedding; ordinary RSS threshold crossings no longer flush NSURLCache and cause avoidable network refetches. Cache clearing is reserved for a real OS memory warning.
- Memory sampling cadence is reduced to 90s FREE / 75s PREMIUM / 60s ADMIN and remains stopped when the app is backgrounded.
- Serious/Critical thermal pressure stops the app-local render schedulers; Low Power Mode applies a half-panel request ceiling. iOS retains full control of CPU/GPU clocks and system throttling.
- Thermal and power notifications refresh existing weakly tracked CADisplayLink instances without creating extra display loops.
- Backgrounding suspends this app's transient optimization work and preserves selected server settings. No AVAudioSession changes are made, so background music from other apps is not interrupted.
- No private display-driver hooks, CPU overclocking, real-time thread priority, or fake Hz/FPS reporting were added.

Validation: shell syntax and static preflight checks only. A full Theos compile and on-device thermal test are still required.
