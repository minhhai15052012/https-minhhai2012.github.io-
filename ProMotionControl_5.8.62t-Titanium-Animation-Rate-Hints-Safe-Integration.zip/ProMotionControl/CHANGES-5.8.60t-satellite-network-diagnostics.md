# 5.8.60t — Satellite Network Diagnostics

- Replaced the former Music tab content with a Satellite diagnostics panel.
- Added a continuously rotating satellite illustration (visual-only) and a foreground-only, 15-second HTTPS latency probe.
- Randomly selects from Cloudflare, Google connectivity-check, Apple success, and 1.1.1.1 endpoints; displays endpoint, HTTP status, and elapsed request time.
- Added NWPathMonitor connectivity/interface status and a handoff button to Cloudflare's official 1.1.1.1/WARP information page.
- Renamed the tab to Satellite and updated its SF Symbol and English tab translation.
- Added Network.framework to the app link dependencies.
- The probe measures HTTPS response time, not ICMP ping, throughput, or a guaranteed improvement in network speed. 1.1.1.1 DNS is not itself a VPN; WARP activation remains a user-confirmed iOS VPN action.
- Satellite motion is a UI animation only. No satellite, cellular tower, baseband, modem, or carrier infrastructure is controlled.
- The selected FREE/PREMIUM/ADMIN profile remains saved and is restored when the app launches/returns to foreground. Active CADisplayLink work is app-scoped and does not continue after force-quit; the OS suspends app work in the background.
- The unsupported Silicon/IOMobileFramebuffer/CAWindowServerDisplay hooks and SCHED_FIFO requests are intentionally not added. The existing public CADisplayLink rate request remains constrained by the physical display and iOS policy.
