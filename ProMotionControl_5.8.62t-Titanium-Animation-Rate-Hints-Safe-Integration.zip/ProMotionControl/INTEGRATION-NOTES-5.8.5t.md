# ProMotionControl 5.8.5t integration notes

- Kept the existing full-featured `Tweak.x`, app profile policy, diagnostics, preference refresh, animation state restoration, and thermal governor. Replacing it wholesale with the supplied short snippet would delete these paths and the snippet is not valid Logos syntax as pasted (method declarations omit the leading `-`, and the final `%ctor`/`@autoreleasepool` braces are not both closed).
- The current `CADisplayLink` path applies user-selected software frame-rate requests only when the process is eligible and the requested target is capped to the native display maximum; it does not promise that actual FPS equals the requested value.
- Existing `DisplayServices` integration already dynamically loads the symbols with `dlopen`/`dlsym`, keeps the feature opt-in, and caps requests to the reported native display maximum. This is not a Sandbox/RootHide bypass.
- Existing `CAMetalLayer` and `MTLRenderPassDescriptor.setVsyncEnabled:` hooks remain conditionally installed. `setAllowsNextDrawableTimeout` remains bounded: forcing `NO` can permit `nextDrawable()` to wait indefinitely and freeze a render thread.
- Added `AVFoundation` import/linkage and an optional `AVPlayer.setRate:` pass-through. The supplied “background audio optimization” block was comments only; it does not implement a CPU or battery optimization.
- Added a no-op `UIEvent.timestamp` compatibility pass-through if that selector exists.
- Added `_UIInternalGestureRecognizer` delay hooks only when both selectors exist, and only activates forcing touch delays off if `TouchLatencyCompatibility=YES` is explicitly set. The default behavior is unchanged to avoid breaking apps that use delayed touch recognition.
- Did not activate fake `ProcessState`/`ThermalMonitor` values or force `NSProcessInfo.thermalState` to nominal / Low Power Mode to disabled. Falsifying these states does not stop actual heat and may defeat device safety behavior. The existing thermal governor remains active.
- Animation OFF handling from the previous integration remains: `GlobalAnimationLockForceOff`, timestamped preference resolution, cache invalidation on Darwin notifications, UIKit animation restoration, and restoration of tracked `CAAnimation` durations.
- `Makefile` links `AVFoundation`; `TARGET = iphone:clang:latest:15.0` is deliberately retained instead of hard-coding `16.5` because this user's Theos previously reported that `iPhoneOS16.5.sdk` was not installed.
- Source version is `5.8.4t`; `build-ubuntu.sh` increments it transactionally to `5.8.5t` for the next build and restores stamped sources on failure.

The full user-supplied snippet and Makefile are preserved verbatim in `REQUESTED-SNIPPETS-REFERENCE/USER-PROVIDED-TWEAKX-AND-MAKEFILE-VERBATIM.txt` for reference. This source archive has not been compiled by Theos in this environment.
