# Integration note — ProMotionControl 5.8.7t source / next build 5.8.8t

This revision uses the full ProMotionControl project/Tweak.x from the supplied archive as its base, rather than replacing the established runtime with the compact 5.8.3 file.

Integrated additions from the compact Tweak.x:
- Read/preserve the `enabled`, `selectedHz`, and `selectedFPS` legacy Filza preferences already supported by the core runtime.
- Add `disableDisplaySync` as a Filza-visible, opt-in gate. `NO` is seeded by default and explicit user choice is preserved; the existing ControlApp Metal compatibility toggle must also be enabled.
- Add a cached battery-critical check and request a maximum of 60 FPS when the reported battery level is at or below 10%, without treating an unavailable battery level as 0%.
- Keep original rate requests bounded by the actual native display capability, thermal governor, Low Power Mode, app policy and existing safety/failsafe logic.

No claim is made that this forces a physical refresh rate beyond the panel, disables Apple's thermal protection, or prevents every app crash. Source package `VERSION` and `Tweak.x` start at 5.8.7t; the included build script increments the package/source to 5.8.8t on the next successful build.

Build status: source and metadata checks only; not built with Theos in this environment.
