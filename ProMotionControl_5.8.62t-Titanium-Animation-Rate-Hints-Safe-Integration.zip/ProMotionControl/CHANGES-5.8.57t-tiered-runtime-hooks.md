# ProMotion Control 5.8.57t — Tiered runtime hook policies

## Scope

This revision strengthens the existing FREE/PREMIUM/ADMIN runtime path without broadening injection beyond the exact standalone ControlApp bundle. It does not inject into arbitrary third-party apps, SpringBoard, Safari, WebKit helpers, or system processes.

## Tier behavior

- FREE: `FreeCADisplayLinkHookEnabled` gates the in-process CADisplayLink policy; the preferred ceiling is 60 FPS and adaptive cadence remains enabled by default.
- PREMIUM: `PremiumCADisplayLinkHookEnabled` gates the same public CADisplayLink surfaces; the ceiling is 120 FPS when the physical display and system state allow it. Low-latency policy selects the configured rate rather than the conservative 90 FPS preference.
- ADMIN: `AdminCADisplayLinkHookEnabled` gates the same public surfaces; the ceiling is up to 244 as a request, but the effective cap is always the device-reported maximum and current iOS thermal/power policy.

## Hook surfaces

- `CADisplayLink.setPreferredFrameRateRange:`
- `CADisplayLink.setPreferredFramesPerSecond:`
- `CADisplayLink.addToRunLoop:forMode:` (applies the active policy when a display link is registered)

The hook reads only atomic scalar state. Preference I/O and nested `ServerProfiles` resolution occur on the serialized preference reload queue. The selected nested server profile is authoritative, with the flat domain retained as a migration/compatibility mirror.

## Safety and stability

- Exact `com.dell.promotioncontrol.app` process identity and matching Theos bundle filter remain mandatory.
- No `SCHED_FIFO`, arbitrary root helper, private SpringBoard hook, V-Sync disabling, hardware clock writes, or system-wide gesture mutation.
- Rate requests are clamped to the physical display maximum; Low Power Mode, charging guard, and Serious/Critical thermal pressure lower the requested cadence.
- The three hook toggles are saved inside each server profile independently.

## Validation

Static source checks, bundle-filter checks, plist parsing, shell syntax checks, and ZIP integrity checks were run. A real Theos/iOS SDK compilation and device runtime test are still required before claiming device-level stability.
