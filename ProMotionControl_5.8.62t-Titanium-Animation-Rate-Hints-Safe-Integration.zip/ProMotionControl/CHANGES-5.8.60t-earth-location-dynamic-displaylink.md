# ProMotion Control — Earth location and dynamic display pacing

- Replaced the former Satellite tab with an Earth simulation and a bundled globe illustration.
- Added opt-in When In Use location permission. A single location sample is shown locally; location updates stop after a valid fix and when leaving the page.
- Kept foreground-only HTTPS latency diagnostics and Network.framework path status; the UI explains that GPS/HTTPS diagnostics do not guarantee lower latency or modify carrier routing.
- Added selected Hz/FPS, hardware maximum, and measured CADisplayLink callback-rate status to the Earth panel.
- Added a weak registry for app-owned CADisplayLink objects so an active server/profile change reapplies its rate to already-running links.
- Existing physical-display, thermal, Low Power, screen-capture, exact-bundle, and process-scope protections remain in place.
- The globe is an illustrative rotating asset, not live satellite imagery, live weather, or a real-time map.
