# ProMotion Control 5.8.61t — Objective-C macro compile fix

- Fixed `PM_SAFE_TRY` to use a variadic macro body (`__VA_ARGS__`).
- This prevents commas inside Objective-C array literals and other protected code blocks from being parsed as extra macro arguments.
- Kept all exception handling, FREE/PREMIUM/ADMIN policies, thermal behavior, and CADisplayLink logic unchanged.
- Added a build preflight assertion so the macro cannot regress to a single-argument definition.

The source still requires a real Theos/iOS SDK build to validate the complete binary.
