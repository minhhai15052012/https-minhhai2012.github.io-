# ProMotionControl 5.8.12t — Power & Thermal Integration

## Integrated from the supplied snippet

- Uses the project's existing RAM-cached preferences and selected `selectedHz` / `selectedFPS` compatibility path.
- Keeps the existing `ThermalGuard`, iOS `NSProcessInfo.thermalState` observer, gradual recovery governor, and native screen maximum cap.
- Keeps the existing opt-in charging-idle render-load reduction: while a user app is foregrounded, charging, and untouched for 90 seconds, the requested rate may be reduced to 30 FPS; touch activity restores the profile target.
- Low-battery detection remains cached and applies a conservative request ceiling. Its previous `batteryMonitoringEnabled` value is now restored in `@finally`, including when reading battery level throws.
- A battery-state notification now re-queues the existing rate policy so charging transitions are reflected promptly.
- Existing SafeShield diagnostics remain best-effort; they do not guarantee that every crash can be caught or recovered from.

## Intentionally not copied verbatim

The following actions from the supplied snippet are not installed: hooks into private `ProcessState` / `ThermalMonitor` methods, faking `thermalLevel = 0`, disabling iOS thermal mitigation, forcing `NSProcessInfo.lowPowerModeEnabled` to `NO`, forcing battery monitoring on in every process, or unconditionally disabling `CAMetalLayer` display synchronization. These can conflict with native power/thermal protections, cause extra heat or rendering artifacts, or target selectors that are not present on all iOS releases. iOS remains responsible for native thermal and power safety.

The supplied `CATransaction setDisableActions:` behavior is also intentionally absent: the active project requirement is to restore native animations and remove the animation-lock option. Disabling Core Animation actions while charging would contradict that requirement and can make UI transitions appear broken.

## Build version

Source tree version: `5.8.12t`. The transactional Ubuntu build script increments the version to `5.8.13t` for the next successful build and restores the source stamp if compilation fails.

## Validation status

Run the included Theos build on Ubuntu/WSL with `THEOS` configured. No claim of successful `.deb` compilation or on-device validation is made until those steps complete.
