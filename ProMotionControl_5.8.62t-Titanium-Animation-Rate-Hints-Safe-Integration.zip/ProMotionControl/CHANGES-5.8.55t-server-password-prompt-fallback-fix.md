# ProMotion Control 5.8.55t — Server password prompt and runtime-marker fallback

- Selecting PREMIUM always opens the PREMIUM password prompt, even if a previous authorization is stored.
- Selecting ADMIN always opens the separate ADMIN password prompt. A Premium grant never substitutes for the Admin password.
- Only a matching password activates the requested protected server. Cancel, wrong password, or authentication persistence failure returns to FREE.
- Removed the “SERVER unavailable / tweak marker not found” popup and the dashboard note that blocked PREMIUM/ADMIN when no exported tweak marker was found.
- Tweak installation identity remains preferred when the tweak is injected. If it is not injected, the standalone app uses a process-scoped fallback identity so password-gated app-local Premium/Admin controls still work; that fallback does not survive a process relaunch.
- When the tweak is injected, authorization remains tied to its package installation ID, so removing/reinstalling the package requires authentication again.
- The control app's local engines can operate without the exported marker, but cross-app tweak hooks still depend on the tweak actually being installed/injected and are not falsely reported as active.
- Kept the five-attempt / 60-second password retry guard and all existing FREE/PREMIUM/ADMIN optimization and thermal protections.
- Build script will stamp version 5.8.55t after a successful build; source VERSION is 5.8.54t.
