# ProMotionControl 5.8.46t — Emergency crash isolation

## Why this hotfix
The previous filter injected the tweak into processes based on ubiquitous UIKit classes (`UIApplication`, `UIScreen`, `CADisplayLink`, `CAMetalLayer`). The runtime then installed a CADisplayLink hook in broadly eligible apps. This is an overly broad injection surface and can conflict with unrelated apps or other tweaks.

## Safety changes
- Substrate filter is now bundle-only and matches only `com.dell.promotioncontrol.app`.
- The process guard requires that exact bundle ID and `/Applications/ProMotionControl.app` path.
- Runtime Logos hook initialization is quarantined (`PMRuntimeHooksAllowedForEmergencyRelease` returns `NO`). No other app gets the dylib, and the control app does not activate CADisplayLink hooks.
- UIKit method swizzling for localization is disabled; static labels still use explicit translation helpers.
- Dashboard CADisplayLink is observational only: it no longer sets preferred FPS/Hz.
- Dashboard no longer polls IORegistry battery temperature every refresh; it displays the supported iOS thermal state instead.
- Existing 5-tab navigation, app-management screens, settings, and saved preferences are preserved.
- Build preflight now rejects broad class-based injection.

## Important limitation
This is an emergency containment build, not a full runtime fix: FPS intervention in other apps is intentionally paused. Re-enable it only after a device crash log identifies the failing path and a narrower per-app implementation is tested. No source-only patch can guarantee crash-free behavior on all devices.

## Build validation
Run `./run-build-ubuntu.sh` in WSL/Ubuntu with Theos and the matching iOS SDK installed. A real `.deb` has not been compiled in this environment.
