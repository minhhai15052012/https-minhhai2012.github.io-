# ProMotionControl 5.8.47t — Objective-C runtime declaration fix

## Build error addressed

`ControlApp/PMControlViewController.m` called `objc_msgSend` in `PMSafeSend`, but the source did not import the Objective-C runtime message header. With the current Theos/Clang warning policy this became a fatal `-Werror,-Wimplicit-function-declaration` error.

## Minimal correction

Added:

```objc
#import <objc/message.h>
```

No selector logic, UI flow, runtime hook, bundle filter, preference key, or package metadata was changed by this hotfix.

## Versioning

The source `VERSION` remains `5.8.46t`, as expected by `run-build-ubuntu.sh`; a successful build stamps `5.8.47t`.

## Validation status

- Confirmed the import occurs exactly once.
- Confirmed the existing `PMSafeSend` call remains unchanged.
- Bash syntax and plist structure checks are run when packaging this source.
- This environment does not include Theos/iPhoneOS SDK, so a real `.deb` build is not claimed.

## Separate warning in the supplied build log

The arm64e ABI linker warning is separate from this compile error. This one-line header fix does not resolve that toolchain compatibility warning; keep it visible and validate the arm64e toolchain separately before treating the build as release-ready.
