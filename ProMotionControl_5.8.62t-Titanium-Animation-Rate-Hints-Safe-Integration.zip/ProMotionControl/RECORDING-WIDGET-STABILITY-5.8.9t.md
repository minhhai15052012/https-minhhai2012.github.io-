# Recording / widget stability integration — source 5.8.9t

- Existing ReplayKit hooks and `UIScreen.isCaptured` diagnostics remain the screen-recording compatibility path. They preserve host callbacks and do not claim to change encoder bitrate or guarantee smooth capture on every device.
- Legacy `selectedHz` / `selectedFPS` values now accept plain numeric values and Base64-encoded numeric strings. Base64 is encoding, not encryption. Values outside 10–244 are not accepted by this compatibility decoder.
- The submitted `SBHWidgetViewController` and `SpringBoard` hooks were not copied literally: the sample calls `%orig` twice in `viewDidLoad` and `applicationDidFinishLaunching:`, which can duplicate initialization. Injecting new private hooks into SpringBoard also conflicts with the project's existing safety policy that excludes SpringBoard and Settings.
- No `ProcessState` / `ThermalMonitor` thermal-limit bypass was added. Disabling thermal safeguards can cause overheating or instability and does not guarantee higher sustained FPS.
- No code can promise 100% crash prevention. The exception handler is diagnostic only; Objective-C exceptions, native memory faults, watchdog termination and jetsam are different failure paths.
- Build kit source version: 5.8.9t. The next successful Ubuntu build should stamp 5.8.10t.
