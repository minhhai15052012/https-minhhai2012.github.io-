# Makefile build optimization (5.8.5t)

- Keeps `arm64 arm64e` for the tweak and `arm64` for ControlApp.
- Uses `iphone:clang:latest:15.0` so Theos selects an installed SDK; iOS 15.0 remains the deployment target. The previous environment reported `iPhoneOS16.5.sdk` was not installed.
- Adds `-Wno-error`, unused-parameter/variable and nullability warning controls, and `-g0` for release build artifacts.
- Does not suppress implicit-function-declaration diagnostics; these can indicate missing declarations and should be fixed at source.
- Makes `-undefined dynamic_lookup` opt-in with `ALLOW_DYNAMIC_LOOKUP=1`, since enabling it by default can hide unresolved symbols and cause runtime failures.
- Retains `PACKAGE_SCHEME=rootless` by default and supports explicitly selecting `rootful`.
- Build script remains responsible for preflight checks, serialized `-j1` compilation, version stamping, transaction rollback and preserving prior `.deb` packages on failure.
