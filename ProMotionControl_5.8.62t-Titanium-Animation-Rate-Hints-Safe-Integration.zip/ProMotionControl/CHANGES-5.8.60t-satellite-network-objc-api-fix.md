# ProMotion Control 5.8.60t — Satellite Network Objective-C SDK compatibility fix

- Replaced Swift-facing `NWPathMonitor` / `NWPath` usage in the Objective-C satellite screen with Network.framework C APIs (`nw_path_monitor_t`, `nw_path_t`).
- Kept the existing connection-state and interface labels (Wi-Fi, cellular, Ethernet), queue confinement, and cancellation lifecycle.
- Updated the build preflight to verify the C API implementation.
- Retained the existing satellite animation and randomized foreground HTTPS latency probes.

This is a source-level compatibility fix. A complete Theos build and device test are still required on the target WSL/iOS SDK environment.
