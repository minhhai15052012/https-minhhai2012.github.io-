# ProMotion Control — ADMIN rate priority and About controls

- ADMIN now retains the selected Hz/FPS request through the Titanium `CAFrameRateRange` path without the previous arbitrary 60 FPS cap while charging or at Fair thermal state.
- FREE and PREMIUM retain their more conservative Fair-thermal and charging policies.
- Serious/Critical thermal pressure, Low Power Mode, and the physical display maximum remain authoritative; requested values are never represented as guaranteed physical output.
- Added About-page appearance choices: Light and Default colors.
- Added About-page language choices: Vietnamese and English.
- Centralized `PMLabel` and `PMButton` localization through `PMTranslateString`, so existing translation entries are actually applied rather than relying on disabled UIKit swizzling.
- Theme and language choices are saved in the app preference domain and trigger the existing UI rebuild path.

Validation: shell syntax, ZIP integrity, source marker checks. A successful Theos build and on-device runtime test are not claimed.
