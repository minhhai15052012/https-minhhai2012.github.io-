# Titanium tiered integration — source 5.8.58t / next build 5.8.59t

## FREE

`PMSmoothEngine` exposes the requested `sharedInstance`, `startEngine`, and
`stopEngine` API. It is a facade over the existing `PMUltimateOptimizer` so the
FREE server has one DisplayLink rather than two competing render loops. The
`FreeSmoothEngineEnabled` switch is stored in the FREE server profile.

## PREMIUM

The Premium Tier-4 configuration adapter is integrated into `Tweak.x`. It uses
the existing synchronized preference snapshot, selected-server resolver,
per-bundle `AppProfiles`, serial Darwin-notification reload, and scalar atomic
runtime values. `PremiumTier4DisplayPolicyEnabled` controls this adapter.

`Titanium_ExecuteTier4Safely` resolves FPS/Hz requests against the physical
display capability and current iOS power/thermal policy. It routes the request
through public `CADisplayLink` frame pacing. No direct private-panel write is
performed.

## ADMIN

`AdminTitaniumHardwareRateAdapterEnabled` selects the ADMIN rate adapter. It
uses the same device-aware target structure (`TitaniumHardwareTarget`) and
maps the request to the existing public `CADisplayLink` hooks. ADMIN remains
connected to the existing `PMUltimateNexusEngine`, `PMCorePerformanceEngine`,
and `PMPowerRefreshEngine` in the ControlApp.

## Hardware/driver code intentionally not activated

The supplied Titanium snippet also contains fake `CADisplayMode` objects,
`pixelClock = 0xFFFFFFFF`, private `IOHIDEventSystemClient`,
`IOMobileFramebufferClient`, `CADisplay`, and `CAWindowServerDisplay` hooks,
forced-success return values, and direct panel-write symbols which are not
provided by this project. These are not compiled or activated: they can lie to
clients about display capability, destabilize WindowServer/SpringBoard, and do
not create a physical refresh mode unsupported by the panel/driver. The source
keeps a safe integration point and uses the supported CADisplayLink API.

## Scope

The installed Substrate filter remains restricted to
`com.dell.promotioncontrol.app`. This build does not claim that game or
third-party processes receive the hooks. No SCHED_FIFO priority changes,
thermal bypass, or system-wide gesture mutation is introduced.
