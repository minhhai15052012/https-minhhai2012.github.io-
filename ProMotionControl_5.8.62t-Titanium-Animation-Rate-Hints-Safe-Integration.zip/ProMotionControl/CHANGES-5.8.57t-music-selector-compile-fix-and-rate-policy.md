# 5.8.57t – Music selector compile fix and rate policy

- Fixed the malformed Objective-C call to `makeMusicValueLabel:size:weight:` in `PMMediaNetworkViewControllers.m`.
- Added a build preflight that checks all five Music value-label calls before Theos compilation.
- Removed arbitrary FREE/PREMIUM/ADMIN 60/90/120-Hz software tier ceilings from the runtime request path.
- FREE, PREMIUM, and ADMIN can request up to the device-reported `maximumFramesPerSecond`; the selected 10–244 range remains a request range, not a hardware unlock.
- Kept iOS-owned thermal, Low Power Mode, charging, and physical display constraints. These cannot safely or reliably be bypassed by a tweak.
- Kept strict process eligibility and existing hook scope; no system-wide injection was enabled.

The source `VERSION` remains 5.8.56t so `run-build-ubuntu.sh` stamps 5.8.57t only after a successful package build.
