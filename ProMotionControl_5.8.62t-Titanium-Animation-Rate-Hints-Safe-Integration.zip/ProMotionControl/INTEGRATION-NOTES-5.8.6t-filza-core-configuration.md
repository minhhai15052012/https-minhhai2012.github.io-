# ProMotionControl 5.8.6t — Filza core preferences integration

- Build baseline is 5.8.6t; the transactional build script advances to 5.8.7t on the next successful build.
- The existing runtime already reads `com.promotioncontrol.prefs` as a compatibility domain through CFPreferences and accepts `selectedHz` / `selectedFPS` as fallback inputs.
- The package `postinst` now seeds `/var/mobile/Library/Preferences/com.promotioncontrol.prefs.plist` if absent and attempts to add only missing keys if `plutil` supports it. Existing values (especially `enabled=false`) are preserved. `GlobalAnimationLock` is not auto-created or enabled.
- Runtime `PMEnsureFilzaCoreConfiguration()` is a best-effort CFPreferences seed for missing keys only. The canonical `com.dell.promotioncontrol` `Enabled` value is used when deciding the legacy lowercase `enabled` default, so an existing master-OFF is not overwritten.
- The raw user-supplied Tweak.x snippet is preserved in `REQUESTED-SNIPPETS-REFERENCE/Tweak.x-filza-core-configuration-5.8.1t-VERBATIM.txt`.
- Deliberately not activated from that raw reference: spoofing thermal state / disabling OS thermal mitigation, and forcing `setAllowsNextDrawableTimeout:NO`. Those behaviors are not portable across iOS releases; drawable timeout NO can leave `nextDrawable()` waiting indefinitely, and spoofing thermal status risks overheating. Actual refresh requests remain capped by the native display maximum.
- Uninstallation leaves user preferences in place. The injected hooks disappear as app processes exit/relaunch; preferences are retained to avoid deleting user configuration.
