# ProMotion Control 5.8.58t – Music provider compatibility

- Separate Apple Music playback controls from third-party music provider launch links.
- Add HTTPS Universal Link buttons for YouTube, Spotify, and Zing MP3.
- Keep Apple Music metadata and transport controls scoped to `MPMusicPlayerController.systemMusicPlayer`.
- Remove the misleading assumption that this app's `MPNowPlayingInfoCenter` dictionary is a cross-process source for another app's Now Playing metadata.
- Explain that third-party playback remains owned by its provider and is controlled through iOS Control Center / Lock Screen controls when the provider supports system Now Playing integration.
- Keep device-native refresh-rate limits and iOS power/thermal protections. The build does not attempt unsupported overclocking or private cross-process media control.
- Update build preflight to validate the external-provider launch actions.

Source VERSION is 5.8.57t; a successful build increments/stamps 5.8.58t.
