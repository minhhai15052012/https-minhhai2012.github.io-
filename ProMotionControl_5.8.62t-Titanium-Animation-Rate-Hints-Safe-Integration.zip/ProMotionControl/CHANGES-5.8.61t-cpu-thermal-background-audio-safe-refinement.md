ProMotion Control 5.8.61t — CPU-work / charging thermal refinement

- Uses exception-safe battery-state reads and restores the prior battery-monitoring state.
- When the charging guard is enabled, both the runtime rate cap and the shared three-tier governor cap this app's requested render cadence at 30 FPS.
- Preserves the existing background suspension path: transient render, monitoring, and stabilizer work stop when ControlApp enters the background.
- Does not modify AVAudioSession, interrupt music, set CPU/GPU clocks, disable iOS thermal throttling, or use private power/thermal interfaces.

Scope: reduces auxiliary work performed by ProMotionControl's own ControlApp process. It cannot force the iPhone CPU to hold a clock rate or directly control another app's audio workload.

Validation performed: source substitutions, static invariant checks, and archive integrity checks only. Full Theos compilation and on-device thermal/audio testing are still required.
