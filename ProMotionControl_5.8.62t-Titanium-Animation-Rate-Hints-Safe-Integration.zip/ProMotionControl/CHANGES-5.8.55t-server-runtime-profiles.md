# ProMotion Control 5.8.55t — Isolated server profiles and tier-aware runtime

## Server selection and persistence
- FREE, PREMIUM and ADMIN each retain a complete independent `ServerProfiles` snapshot.
- The active profile is flattened into the canonical `com.dell.promotioncontrol` preferences domain on selection; switch changes, rate choices and per-app profiles are persisted back into the currently selected server snapshot.
- The app continues to select the matching app-local engine for the active server.

## Tier-specific runtime policy
- The Logos `CADisplayLink` hook now reads the active server mode and its own render, thermal, charging and cadence switches.
- The hook reads the canonical preference snapshot, overlays only a limited set of settings from the current process's matching `AppProfiles` entry, and reloads after the Darwin preference-change notification.
- FREE uses a conservative adaptive preferred cadence; PREMIUM can prefer the selected ceiling in low-latency mode; ADMIN applies its adaptive frame-pacing policy and extra app-local view/scroll controls.
- Every requested rate remains capped by the physical display maximum, the incoming display-link range, Low Power Mode and iOS thermal policy. Serious/Critical thermal pressure always wins.

## Scope and limits
- Injection remains limited by `ProMotionControl.plist` and the process identity guard to `com.dell.promotioncontrol.app`. This is an intentional crash-containment boundary. The per-app profiles for other installed apps are stored independently but are **not** applied inside those apps by this build; enabling that would require a separately tested, explicitly scoped injection mechanism.
- The runtime hook changes `CADisplayLink` requests only. It does not overclock CPU/GPU, bypass thermal limits, unlock a display's unsupported refresh rates, or guarantee game FPS.
- “2x” and “5x” are not measurable performance multipliers that an iOS tweak can guarantee. The tiers differ by enabled feature set and policy, not by promised hardware speed multipliers.

## Validation
- Build-script preflight blocks, shell syntax, plist parsing, Objective-C delimiter checks and archive integrity were checked in this environment.
- A full Theos/iOS SDK compile and on-device crash test were not available here.
