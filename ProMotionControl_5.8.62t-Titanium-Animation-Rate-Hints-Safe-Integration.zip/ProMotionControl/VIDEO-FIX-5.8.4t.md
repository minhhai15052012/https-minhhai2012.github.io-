# Video fixes — 5.8.4t

- Normal app launch now installs the real five-tab root directly. `PMRecoveryLaunchController` is retained only as a fallback if root creation returns nil or throws, fixing the recurring safe-launch splash visible in the submitted recording.
- The animation toggle now persists `GlobalAnimationLockForceOff` together with `GlobalAnimationLockUpdatedAt`. Runtime preference resolution treats a same-timestamp explicit OFF marker as authoritative, and the animation lock is subordinate to the master `Enabled` switch.
- If the manager cannot verify a setting write, its animation switch is reconciled with the value currently read from the preferences domain instead of leaving a misleading OFF display while the runtime may still read ON.
- Preferences read-back verifies each changed key when either Foundation or CoreFoundation confirms it; one stale cached API no longer automatically invalidates an otherwise confirmed write.

The next `build-ubuntu.sh` run increments baseline version 5.8.3t to 5.8.4t. Theos compilation and device behavior still require verification on the user's machine/device.
