# Titanium Core Animation rate hints — 5.8.62t source integration

## Integrated

- `CAAnimation.setPreferredFrameRateRange:` now routes animation rate requests through the existing selected-server governor.
- `CALayer.addAnimation:forKey:` applies the same resolved range to animations before attaching them.
- FREE, PREMIUM, and ADMIN all use `PMRateRangeForActiveServer`; their existing per-tier preferences and authorization remain authoritative.
- The range is bounded by `UIScreen.maximumFramesPerSecond`, the selected Hz/FPS values, Low Power Mode, and the existing iOS thermal policy.
- Animation `speed`, duration, timing curves, and completion behavior are not rewritten.
- The existing `CADisplayLink` path remains the shared frame callback path; no duplicate RenderServer/CADisplayLink hook is added.

## Not integrated from the supplied snippets

- The supplied `setFrameRateRange:` / `anim.frameRateRange` names are replaced by the public `preferredFrameRateRange` property.
- No `UIView` duration multiplier is added: changing duration changes animation timing, not display refresh rate.
- No `CARenderServer`, `CAWindowServer`, `IOMobileFramebufferClient`, `CAWindowServerDisplay`, `CADisplay`, or `IORegistryEntry` private hooks are added.
- No fake pixel-clock/timing flags, fabricated driver success result, V-Sync bypass, thermal-state spoof, Low Power Mode spoof, or forced real-time thread priority is added. Those operations do not safely unlock the panel and can break system scheduling or thermal protection.
- No background keep-alive loop is added. The tweak remains scoped to `com.dell.promotioncontrol.app`; iOS can suspend an app in the background. Existing lifecycle observers refresh/restore display-link pacing at foreground/background transitions.

## Scope

The package's Theos filter intentionally injects only into the ProMotionControl app. These animation hints therefore affect animations created by that app, not every SpringBoard/system animation or every third-party app.

## Validation

Source and build-script syntax checks can be run in this environment, but a real Theos compile and on-device thermal/display test require the user's WSL Theos toolchain and iPhone.
