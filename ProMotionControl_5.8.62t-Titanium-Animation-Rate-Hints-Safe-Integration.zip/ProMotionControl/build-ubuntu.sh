#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${THEOS:?THEOS is not set. Example: export THEOS=$HOME/theos}"
MAKE_BIN="${MAKE_BIN:-}"
if [[ -z "$MAKE_BIN" ]]; then
    if command -v gmake >/dev/null 2>&1; then
        MAKE_BIN="$(command -v gmake)"
    elif command -v make >/dev/null 2>&1; then
        MAKE_BIN="$(command -v make)"
    else
        echo "GNU make is required (install make; on macOS use gmake)." >&2
        exit 1
    fi
fi
command -v python3 >/dev/null || { echo "python3 is required to validate plist files" >&2; exit 1; }

# Recover a partially stamped source tree if the previous WSL session was stopped.
# Existing .deb files are kept until a newly built package passes all validation.
RECOVERY_DIR="$PWD/.build-recovery"
PM_VERIFY_TMP=""
pm_restore_interrupted_build() {
    if [[ -f "$RECOVERY_DIR/ACTIVE" ]]; then
        local next_version rel
        next_version="$(cat "$RECOVERY_DIR/NEXT_VERSION" 2>/dev/null || true)"
        if [[ -f "$RECOVERY_DIR/FILES" ]]; then
            while IFS= read -r rel; do
                [[ -n "$rel" ]] || continue
                if [[ -f "$RECOVERY_DIR/snapshot/$rel" ]]; then
                    mkdir -p "$(dirname "$rel")"
                    cp -p "$RECOVERY_DIR/snapshot/$rel" "$rel"
                fi
            done < "$RECOVERY_DIR/FILES"
        fi
        if [[ -n "$next_version" && -d packages ]]; then
            find packages -maxdepth 1 -type f -name "*${next_version}*.deb" -delete 2>/dev/null || true
        fi
        rm -rf "$RECOVERY_DIR"
        echo "Recovered source/version after interrupted build; prior packages were preserved."
    elif [[ -d "$RECOVERY_DIR" ]]; then
        rm -rf "$RECOVERY_DIR"
    fi
}
pm_restore_interrupted_build

pm_on_exit() {
    local status=$?
    trap - EXIT
    if [[ -n "${PM_VERIFY_TMP:-}" && -d "$PM_VERIFY_TMP" ]]; then
        rm -rf "$PM_VERIFY_TMP" || true
    fi
    if [[ $status -ne 0 && -f "$RECOVERY_DIR/ACTIVE" ]]; then
        echo "Build failed (exit $status); restoring VERSION/Tweak/control/plists and keeping previous .deb packages." >&2
        pm_restore_interrupted_build || true
    fi
    exit "$status"
}

# Refuse to build a stale Preferences-only source tree.
if ! grep -Eq '^[[:space:]]*SUBPROJECTS[[:space:]]*=[[:space:]]*ControlApp[[:space:]]*$' Makefile; then
    echo "ERROR: wrong source tree: top-level Makefile must set SUBPROJECTS = ControlApp." >&2
    echo "This package must contain the standalone ProMotionControl.app; refusing to continue." >&2
    exit 1
fi
if grep -Eq '^[[:space:]]*SUBPROJECTS[[:space:]]*=.*(Preferences|Legacy)' Makefile; then
    echo "ERROR: legacy Preferences subproject is enabled; refusing to build." >&2
    exit 1
fi
if grep -Eq 'PMRootListController\.m|ProMotionControlPrefs|APPLICATION_NAME[[:space:]]*=[[:space:]]*ProMotionControlPrefs' Makefile ControlApp/Makefile; then
    echo "ERROR: legacy Preferences target detected in active Makefiles; refusing to build." >&2
    exit 1
fi
if ! grep -Eq '^[[:space:]]*APPLICATION_NAME[[:space:]]*=[[:space:]]*ProMotionControlApp[[:space:]]*$' ControlApp/Makefile; then
    echo "ERROR: ControlApp is not configured as ProMotionControlApp; refusing to build." >&2
    exit 1
fi
for required in ControlApp/Makefile ControlApp/main.m ControlApp/PMAppDelegate.m \
                ControlApp/PMControlViewController.m ControlApp/PMPremiumOptimizationEngine.h \
                ControlApp/PMPremiumOptimizationEngine.m ControlApp/PMPerformanceSuite.h \
                ControlApp/PMPerformanceSuite.m ControlApp/PMLocalBridge.h \
                ControlApp/PMLocalBridge.m ControlApp/PMEarthNetworkViewControllers.h \
                ControlApp/PMEarthNetworkViewControllers.m ControlApp/Resources/Info.plist ControlApp/Resources/EarthGlobe.png \
                ControlApp/Resources/AppIcon60x60@2x.png ControlApp/Resources/AppIcon60x60@3x.png \
                ControlApp/Resources/AppIcon76x76@2x.png; do
    if [[ ! -s "$required" ]]; then
        echo "ERROR: required app source/resource missing: $required" >&2
        exit 1
    fi
done
python3 - <<'PREFLIGHT'
import plistlib
from pathlib import Path
with Path('ControlApp/Resources/Info.plist').open('rb') as f:
    info = plistlib.load(f)
assert info.get('CFBundleIdentifier') == 'com.dell.promotioncontrol.app', 'Unexpected app Bundle ID'
assert info.get('CFBundleExecutable') == 'ProMotionControlApp', 'Unexpected executable name'
assert info.get('CFBundlePackageType') == 'APPL', 'Target is not a standalone application'
assert info.get('CFBundleDisplayName') == 'ProMotion Control', 'Unexpected app display name; expected ProMotion Control'
assert info.get('NSLocationWhenInUseUsageDescription'), 'Missing purpose string for user-requested Earth location display'
assert not info.get('NSAppleMusicUsageDescription'), 'Obsolete Apple Music permission string remains after media-page replacement'
PREFLIGHT

if ! grep -Fq 'PMPremiumOptimizationEngine.m' ControlApp/Makefile; then
    echo "ERROR: Premium optimization engine is not part of the ControlApp build." >&2
    exit 1
fi
if ! grep -Fq 'PMPerformanceSuite.m' ControlApp/Makefile; then
    echo "ERROR: shared performance suite is not part of the ControlApp build." >&2
    exit 1
fi
if ! grep -Fq 'PMLocalBridge.m' ControlApp/Makefile; then
    echo "ERROR: optional ADMIN local bridge is not part of the ControlApp build." >&2
    exit 1
fi
if ! grep -Fq 'PMEarthNetworkViewControllers.m' ControlApp/Makefile || ! grep -Fq 'Network' ControlApp/Makefile || ! grep -Fq 'SystemConfiguration' ControlApp/Makefile || ! grep -Fq 'CoreLocation' ControlApp/Makefile || grep -Fq 'MediaPlayer' ControlApp/Makefile; then
    echo "ERROR: Earth/Network pages or required frameworks are missing from the ControlApp build." >&2
    exit 1
fi
python3 - <<'ADMIN_BRIDGE_CHECK'
from pathlib import Path
bridge = Path('ControlApp/PMLocalBridge.m').read_text(errors='replace')
for token in ['PM_SOCKET_PATH', 'lstat(', 'S_ISSOCK', 'getpeereid(', 'PM_BRIDGE_TIMEOUT_MS', 'thermal_reduce', 'thermal_resume', 'status']:
    if token not in bridge:
        raise SystemExit('ERROR: ADMIN bridge security/protocol check missing: ' + token)
for forbidden in ['popen(', 'system(', 'execve(', 'setuid(', 'seteuid(']:
    if forbidden in bridge:
        raise SystemExit('ERROR: arbitrary command execution detected in ADMIN bridge: ' + forbidden)
print('Verified root-peer-checked, timeout-bound, allowlisted ADMIN Unix socket client.')
ADMIN_BRIDGE_CHECK
python3 - <<'PREMIUM_ENGINE_CHECK'
from pathlib import Path
header = Path('ControlApp/PMPremiumOptimizationEngine.h').read_text(errors='replace')
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
controller = Path('ControlApp/PMControlViewController.m').read_text(errors='replace')
required_engine = [
    '@interface PMUltimateOptimizer', 'deployUltimateOptimizationsWithOptions:', 'stopOptimizations',
    '@interface PMSmoothEngine', 'startEngineWithOptions:', 'FreeSmoothEngineEnabled',
    'CAFrameRateRangeMake(', 'FreeRenderSchedulerEnabled', 'FreeThermalGuardEnabled',
    '@interface PMAdvancedOptimizer', 'startHighPerformanceRenderLoopWithThermalGuard:',
    'PremiumRenderSchedulerEnabled', 'PremiumLowLatencyModeEnabled',
    'preferredFrameRateRange', 'CAFrameRateRangeMake(', 'PremiumChargingGuardEnabled',
    'NSRunLoopCommonModes', '- (void)stopRenderLoop',
    '@interface PMInputAndDisplayBooster', 'activateFreeOptimizationWithOptions:',
    'activatePremiumOptimizationWithOptions:', 'suspendOptimizations',
    'boostKeyboardAndTouchResponsiveness', 'preventLowPowerFrameDrops',
    'NSProcessInfoPowerStateDidChangeNotification',
    'NSProcessInfoThermalStateDidChangeNotification', 'delaysContentTouches = NO',
    'maximumVisitedViews = 4096', 'UIApplicationDidEnterBackgroundNotification',
]
missing = [item for item in required_engine if item not in header + '\n' + engine]
if missing:
    raise SystemExit('ERROR: Premium engine integration incomplete: ' + ', '.join(missing))
if 'activatePremiumOptimization' not in controller or 'deactivatePremiumOptimization' not in controller:
    raise SystemExit('ERROR: Premium engine is not connected to FREE/PREMIUM lifecycle.')
for forbidden in ['pthread_setschedparam', 'SCHED_FIFO', 'delaysTouchesBegan', 'delaysTouchesEnded', 'beginActivityWithOptions:0x00FFFFFF', 'popen(', 'setuid(0)']:
    if forbidden in engine:
        raise SystemExit('ERROR: unsafe global input/priority/root operation detected: ' + forbidden)
print('Verified Premium render loop, app-scoped scroll touch tuning, foreground lifecycle, and power/thermal guard.')
PREMIUM_ENGINE_CHECK

python3 - <<'PERFORMANCE_SUITE_CHECK'
from pathlib import Path
header = Path('ControlApp/PMPerformanceSuite.h').read_text(errors='replace')
source = Path('ControlApp/PMPerformanceSuite.m').read_text(errors='replace')
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
required = [
    '@interface PMPerformanceMonitor', 'recordFrameTimestamp:', 'shouldThrottleAuxiliaryWork',
    '@interface PMPowerRefreshEngine', 'configureRefreshRateFromMin:', 'PMPowerRefreshEngine',
    '@interface PMCorePerformanceEngine', 'deployCorePerformanceEngineWithMinRate:',
    'optimizeViewRendering:', '@interface PMSysStabilizerEngine',
    'deploySystemStabilizerForServerMode:', 'UIApplicationDidReceiveMemoryWarningNotification',
    'MACH_TASK_BASIC_INFO', '@interface PMUltimateNexusEngine',
    'deployNexusPerformanceSuiteWithMinRate:', 'shutdownNexusEngine',
    'shouldThrottleAuxiliaryWork', 'setMemoryPressureActive:',
]
missing = [item for item in required if item not in header + '\n' + source]
if missing:
    raise SystemExit('ERROR: integrated performance suite incomplete: ' + ', '.join(missing))
for token in ['PMPerformanceMonitor sharedMonitor] startMonitoring', 'PMSysStabilizerEngine sharedEngine] deploySystemStabilizerForServerMode:0', 'deploySystemStabilizerForServerMode:1', 'deploySystemStabilizerForServerMode:2', 'recordFrameTimestamp:sender.timestamp', 'deployMaximumPerformanceModeWithOptions:snapshot', 'deployAdaptiveGovernorWithHz:maximum', 'serverMode:0', 'serverMode:1', 'serverMode:2', 'PMEngineThermalSafeMaximumRate(requestedMaximum, mode']:
    if token not in engine:
        raise SystemExit('ERROR: tier lifecycle not connected to performance suite: ' + token)
for forbidden in ['pthread_setschedparam', 'SCHED_FIFO', 'delaysTouchesBegan', 'delaysTouchesEnded',
                  'postNotificationName:UIApplicationDidReceiveMemoryWarningNotification', 'vm_allocate(']:
    if forbidden in source:
        raise SystemExit('ERROR: unsafe/ineffective system-wide operation detected in performance suite: ' + forbidden)
stabilizer_start = source.find('- (void)purgeSystemMemoryIfNeeded {')
stabilizer_end = source.find('- (void)stopStabilizer {', stabilizer_start)
stabilizer = source[stabilizer_start:stabilizer_end]
if 'removeAllCachedResponses' in stabilizer:
    raise SystemExit('ERROR: periodic RSS monitor must not clear URL cache and trigger avoidable network reloads.')
if 'setMemoryPressureActive:' not in source or 'threshold * 85ULL / 100ULL' not in source:
    raise SystemExit('ERROR: memory-pressure load-shed / recovery hysteresis is missing.')
print('Verified tier-aware Core/Refresh/Nexus engines, frame monitor, RSS hysteresis, and real-warning-only cache clearing.')
PERFORMANCE_SUITE_CHECK

# Titanium FREE/PREMIUM/ADMIN integration preflight. The active runtime must
# use the public CADisplayLink path and must not reintroduce hidden driver hooks.
python3 - <<'TITANIUM_INTEGRATION_CHECK'
from pathlib import Path
header = Path('ControlApp/PMPremiumOptimizationEngine.h').read_text(errors='replace')
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
controller = Path('ControlApp/PMControlViewController.m').read_text(errors='replace')
tweak = Path('Tweak.x').read_text(errors='replace')
if '#define PM_SAFE_TRY(...)' not in tweak:
    raise SystemExit('ERROR: PM_SAFE_TRY must be variadic so Objective-C collection-literal commas compile safely.')
required = [
    'PMSmoothEngine', 'startEngineWithOptions:', 'FreeSmoothEngineEnabled',
    'PremiumTier4DisplayPolicyEnabled', 'AdminTitaniumHardwareRateAdapterEnabled',
    'TitaniumHardwareTarget', 'Titanium_GetHardwareMaximum',
    'Titanium_ResolvePremiumTier4Target', 'Titanium_ResolveAdminHardwareTarget',
    'Titanium_ExecuteTier4Safely', 'Titanium_MakeSafeFrameRange',
    'PMPolicyPremiumTier4Display', 'PMPolicyAdminTitaniumRateAdapter',
    'g_TargetHz', 'PMGetTargetHz', 'PM_DARWIN_CHANGED_NOTIFICATION',
    'PMPreferencesForSelectedServer', 'PMEffectivePreferencesForCurrentApp',
    'FreeChargingGuardEnabled',
    'g_PMStateObserverTokens', 'NSProcessInfoThermalStateDidChangeNotification',
    'NSProcessInfoPowerStateDidChangeNotification', 'PMRefreshTrackedDisplayLinks();',
]
combined = header + '\n' + engine + '\n' + controller + '\n' + tweak
missing = [token for token in required if token not in combined]
if missing:
    raise SystemExit('ERROR: Titanium tier integration incomplete: ' + ', '.join(missing))
for forbidden in [
    '%hook IOMobileFramebufferClient', '%hook IOHIDEventSystemClient',
    '%hook CAWindowServerDisplay', '%hook CADisplay\n',
    'TitaniumFakeDisplayMode', 'Titanium_ForcePanelModeDirect',
    'SCHED_FIFO', 'pthread_setschedparam',
]:
    if forbidden in tweak:
        raise SystemExit('ERROR: unsupported private driver/real-time hook found in active Tweak.x: ' + forbidden)
if '<string>com.dell.promotioncontrol.app</string>' not in Path('ProMotionControl.plist').read_text(errors='replace'):
    raise SystemExit('ERROR: strict ControlApp injection filter was changed unexpectedly.')
print('Verified FREE PMSmoothEngine facade, PREMIUM safe Tier-4 adapter, ADMIN device-aware Titanium adapter, and strict process scope.')

TITANIUM_INTEGRATION_CHECK

# Shared Titanium governor / ADMIN foreground transition integration.
python3 - <<'GOVERNOR_CHECK'
from pathlib import Path
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
header = Path('ControlApp/PMPremiumOptimizationEngine.h').read_text(errors='replace')
ui = Path('ControlApp/PMControlViewController.m').read_text(errors='replace')
required_engine = [
    'TitaniumAdaptiveGovernorEngine', 'deployAdaptiveGovernorWithHz:',
    'serverMode:0', 'serverMode:1', 'serverMode:2',
    'startAdaptiveWatchdog', 'stopAdaptiveWatchdog',
    'UIApplicationDidBecomeActiveNotification', 'TitaniumUltimateHomeShieldEngine',
    'triggerHomeStutterShieldBoostWithHandler:'
]
required_ui = ['AdminHomeTransitionShieldEnabled', 'Admin Foreground Transition Assist']
missing = [token for token in required_engine if token not in engine and token not in header]
missing += [token for token in required_ui if token not in ui]
if missing:
    raise SystemExit('ERROR: Titanium three-tier governor / ADMIN transition integration incomplete: ' + ', '.join(missing))
for forbidden in ['pthread_setschedparam', 'SCHED_FIFO', 'killWithContext:', '%hook SBMainWorkspace', 'KeepAlive']:
    if forbidden in engine or forbidden in header or forbidden in Path('Tweak.x').read_text(errors='replace'):
        raise SystemExit('ERROR: unsupported privileged/system-wide operation detected: ' + forbidden)
print('Verified shared Titanium thermal governor for FREE/PREMIUM/ADMIN, foreground-only watchdog, and app-local ADMIN transition assist.')
GOVERNOR_CHECK

# Earth/location/network UI and persistent server lifecycle preflight.
python3 - <<'EARTH_NETWORK_CHECK'
from pathlib import Path
source = Path('ControlApp/PMEarthNetworkViewControllers.m').read_text(errors='replace')
controller = Path('ControlApp/PMControlViewController.m').read_text(errors='replace')
required = [
    '@interface PMEarthViewController', 'EARTH POSITION & NETWORK',
    'BẢN ĐỒ TRÁI ĐẤT MÔ PHỎNG', 'EarthGlobe', 'pm.earth.continuousRotation',
    'requestWhenInUseAuthorization', 'startUpdatingLocation', 'didUpdateLocations:', 'stopUpdatingLocation',
    'locationBar', 'location.fill', 'updateEarthRefreshPolicy', 'NSProcessInfoThermalStateCritical',
    'nw_path_t', 'nw_path_monitor_create', 'nw_path_monitor_set_update_handler',
    'nw_path_uses_interface_type', 'nw_path_monitor_start', 'nw_path_monitor_cancel',
    'https://1.1.1.1/cdn-cgi/trace', 'https://www.cloudflare.com/cdn-cgi/trace',
    'https://www.google.com/generate_204', 'https://connectivitycheck.gstatic.com/generate_204',
    'https://captive.apple.com/hotspot-detect.html',
    'arc4random_uniform', 'runEarthProbe', 'updateSelectedTierAndRates',
    'UIScreen.mainScreen.maximumFramesPerSecond', 'measuredFramesPerSecond',
    'https://one.one.one.one/', 'không tự giảm ping', 'không thể can thiệp tuyến mạng',
    '@interface PMNetworkViewController', 'getifaddrs(',
    'CNCopyCurrentNetworkInfo', 'startNetworkUpdates', 'stopNetworkUpdates',
]
missing = [item for item in required if item not in source]
if missing:
    raise SystemExit('ERROR: Earth/Network feature missing: ' + ', '.join(missing))
if 'locationAccuracyLabel' in source:
    raise SystemExit('ERROR: Earth page must present one combined iPhone location indicator bar.')
if '[PMEarthViewController new]' not in controller or '[PMNetworkViewController new]' not in controller:
    raise SystemExit('ERROR: Earth and Network pages are not installed in the root tab controller.')
if '5 tabs: Home, Apps, About, Earth, Network' not in controller:
    raise SystemExit('ERROR: root tab diagnostics do not describe the five pages.')
implementation_start = controller.index('@implementation PMControlViewController')
view_start = controller.index('- (void)viewWillDisappear:(BOOL)animated', implementation_start)
view_end = controller.index('- (void)viewDidDisappear:', view_start + 1)
view_exit = controller[view_start:view_end]
if 'suspendOptimizations' in view_exit:
    raise SystemExit('ERROR: server engines are incorrectly stopped when switching tabs.')
background_start = controller.index('- (void)premiumApplicationDidEnterBackground:', implementation_start)
resume_start = controller.index('- (void)premiumApplicationDidBecomeActive:', background_start + 1)
resume_end = controller.index('- (void)applyPremiumPreset:', resume_start + 1)
background = controller[background_start:resume_start]
resume = controller[resume_start:resume_end]
if 'suspendOptimizations' not in background or 'PMSetPremiumSelectedMode' in background or 'PMSetAdminSelectedMode' in background or 'ActiveServerMode' in background:
    raise SystemExit('ERROR: app background handler must suspend transient work without clearing the saved server.')
if 'prepareServerProfilesForLaunch' not in resume or 'refreshActiveServerRuntime' not in resume:
    raise SystemExit('ERROR: server selection is not restored through the gated runtime router when the app becomes active.')
runtime_start = controller.index('- (void)refreshActiveServerRuntime', implementation_start)
runtime_end = controller.index('- (NSTimeInterval)dashboardTelemetryInterval', runtime_start)
runtime_router = controller[runtime_start:runtime_end]
for token in ['options[@"Enabled"]', 'deactivatePremiumOptimization', 'activateAdminOptimizationWithOptions:', 'activatePremiumOptimizationWithOptions:', 'activateFreeOptimizationWithOptions:']:
    if token not in runtime_router:
        raise SystemExit('ERROR: selected-tier master-switch routing is incomplete: ' + token)
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
if 'FreeSmoothEngineEnabled' not in engine:
    raise SystemExit('ERROR: FREE Smooth Engine switch is not honored by the runtime engine.')
for token in ['PMCurrentServerAuthorizationInstallationID', 'PMShouldAutoActivatePremium', 'PMShouldAutoActivateAdmin', 'PMAdminAuthorizationMatchesCurrentInstall', 'PMPremiumAuthorizationMatchesCurrentInstall']:
    if token not in controller:
        raise SystemExit('ERROR: persistent server authorization/restore missing: ' + token)
print('Verified single iPhone location bar, foreground GPS tracking, adaptive foreground probes, selected-tier switch routing, and saved server restore.')
EARTH_NETWORK_CHECK

# Rate policy preflight: remove fixed server-tier ceilings, but retain physical
# display and OS thermal/power safety boundaries.
python3 - <<'RATE_POLICY_CHECK'
from pathlib import Path
engine = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
tweak = Path('Tweak.x').read_text(errors='replace')
for forbidden in [
    'MIN(120, MAX(60, deviceMaximum',
    'MIN(maximum, 90.0)',
    'tierMaximum',
]:
    if forbidden in engine + '\n' + tweak:
        raise SystemExit('ERROR: artificial server-tier rate ceiling remains: ' + forbidden)
for required in [
    'UIScreen.mainScreen.maximumFramesPerSecond',
    'NSProcessInfoThermalStateSerious',
    'NSProcessInfoThermalStateCritical',
    'isLowPowerModeEnabled',
    'FreeChargingGuardEnabled', 'PMThermalTargetCap',
]:
    if required not in engine + '\n' + tweak:
        raise SystemExit('ERROR: required device/OS safety boundary missing: ' + required)
if 'PMRuntimeDeviceIsCharging()' in tweak or 'chargingGuard && PMEngineDeviceIsCharging()' in engine:
    raise SystemExit('ERROR: charger-only Hz/FPS cap detected; charging must not lower selected display targets.')
print('Verified charging does not cap selected Hz/FPS; native display, Low Power and iOS thermal limits remain active.')
RATE_POLICY_CHECK

# Guardrails for rate reporting, process scope, and QuartzCore type declarations.
# CAFrameRateRange is declared by QuartzCore; do not redeclare the struct locally.
if grep -Eq '^[[:space:]]*struct[[:space:]]+CAFrameRateRange[[:space:]]*\{' Tweak.x; then
    echo "ERROR: Tweak.x redeclares CAFrameRateRange already provided by QuartzCore." >&2
    exit 1
fi
# setenv does not grant sandbox/RootHide privileges; do not reintroduce the fake override env var.
if grep -Eq 'setenv[[:space:]]*\([[:space:]]*"CADISPLAYLINK_FORCE_RATE"' Tweak.x; then
    echo "ERROR: unsupported CADISPLAYLINK_FORCE_RATE environment spoof detected." >&2
    exit 1
fi
if ! grep -q 'PMExecutableLooksLikeInstalledAppProcess' Tweak.x; then
    echo "ERROR: missing app-bundle eligibility guard before runtime hook installation." >&2
    exit 1
fi
if ! grep -q 'PMRuntimeHooksAllowedForEmergencyRelease' Tweak.x || \
   ! grep -q 'return PMCheckAppEligibility();' Tweak.x || \
   ! grep -q 'exact ControlApp runtime hook initialized' Tweak.x; then
    echo "ERROR: exact-bundle ControlApp runtime hook gate is missing." >&2
    exit 1
fi
if ! grep -q 'PM_DARWIN_CHANGED_NOTIFICATION' Tweak.x || \
   ! grep -q 'PMDarwinPreferencesChanged' Tweak.x || \
   ! grep -q 'PMRefreshTrackedDisplayLinks' Tweak.x || \
   ! grep -q 'g_PMTrackedDisplayLinks' Tweak.x || \
   ! grep -q 'PMRegisterDisplayLink' Tweak.x || \
   ! grep -q 'g_PMApplyingTrackedRate' Tweak.x || \
   ! grep -q 'g_PMOriginalDisplayLinkRates' Tweak.x || \
   ! grep -q 'appForeground' Tweak.x || \
   ! grep -q 'com.dell.promotioncontrol.plist' Tweak.x; then
    echo "ERROR: live canonical preference reload path is missing from Tweak.x." >&2
    exit 1
fi
# Multi-layer SafeShield integration guards: preserve the supported user-app scope,
# native animations, and system-owned thermal/power protections.
if ! grep -q 'PMLegacyFilzaPreferenceCachedSnapshot' Tweak.x || \
   ! grep -q 'PMInstallSafetyExceptionHandler' Tweak.x || \
   ! grep -q 'PMThermalTargetCap' Tweak.x || \
   ! grep -q 'PMRefreshScreenCaptureState' Tweak.x; then
    echo "ERROR: missing a required cached-preference, diagnostic, thermal-governor, or capture-state component." >&2
    exit 1
fi
if grep -Eq '^%hook[[:space:]]+(SBHWidgetViewController|SpringBoard|ProcessState|ThermalMonitor|NSProcessInfo|UIDevice|CATransaction)[[:space:]]*$' Tweak.x; then
    echo "ERROR: unsupported private SpringBoard/thermal/power or global animation override hook detected." >&2
    exit 1
fi
if grep -Eq '^%hook[[:space:]]+UIView[[:space:]]*$|^%hook[[:space:]]+CATransaction[[:space:]]*$|PMShouldLockUIKitAnimations|PMApplyAnimationLock' Tweak.x; then
    echo "ERROR: retired native-animation override detected." >&2
    exit 1
fi
if grep -Eq 'PMShouldLockUIKitAnimations|PMApplyAnimationLock|PMRestoreAnimationLockState|PMAnimationLockOriginalStateCaptured|PMAnimationLockWatchdogTimer|PMRestoreTrackedAnimationDurations' Tweak.x; then
    echo "ERROR: retired animation-lock runtime code is still present in Tweak.x." >&2
    exit 1
fi
if grep -Eq '^%hook[[:space:]]+(UIView|CATransaction)[[:space:]]*$' Tweak.x; then
    echo "ERROR: native animation hooks must remain removed." >&2
    exit 1
fi
if grep -Fq '@"title": @"Khóa animation"' ControlApp/PMControlViewController.m; then
    echo "ERROR: obsolete animation-lock switch is still visible in ControlApp." >&2
    exit 1
fi
if ! grep -Eq '^[[:space:]]*%init[[:space:]]*;' Tweak.x; then
    echo "ERROR: Tweak.x contains implicit (_ungrouped) Logos hooks but does not initialize them with %init;." >&2
    exit 1
fi
python3 - <<'LOGOS_INIT_CHECK'
import re
from collections import Counter
from pathlib import Path
source = Path('Tweak.x').read_text(errors='replace')
# Count named group initialization directives, not group declarations.
names = re.findall(r'%init\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*;', source)
duplicates = sorted(name for name, count in Counter(names).items() if count > 1)
if duplicates:
    raise SystemExit('ERROR: Logos named groups initialized more than once: ' + ', '.join(duplicates))
LOGOS_INIT_CHECK
# Live dashboard preflight: require real telemetry sampling, visible-only lifecycle,
# and a central board containing every distinct global switch key already in source.
python3 - <<'LIVE_DASHBOARD_CHECK'
import re
from pathlib import Path
source = Path('ControlApp/PMControlViewController.m').read_text(errors='replace')
required = [
    '@interface PMTelemetryWaveformView',
    'NSTimeInterval interval = 0.2;',
    'NSTimeInterval telemetryInterval = [self dashboardTelemetryInterval];',
    'dashboardTelemetryInterval',
    'forMode:NSRunLoopCommonModes',
    '[self.dashboardMetricsTimer invalidate]',
    'dashboardColumns.axis = landscapeLayout',
    'FPS CHỌN',
    'HZ CHỌN',
    'CPU LOAD',
    'SERVER FREE',
    'SERVER PREMIUM',
    'SERVER ADMIN',
    'BẢO VỆ TỔNG QUAN: ĐÃ KÍCH HOẠT',
    'PMInstalledAppIconForProxy',
    'skipCPUSampleForHeat',
    'desiredTelemetryInterval',
    '@"proxy": app[@"proxy"] ?: [NSNull null]',
]
missing = [item for item in required if item not in source]
if missing:
    raise SystemExit('ERROR: live dashboard preflight missing: ' + ', '.join(missing))
def keys_for_array(name):
    match = re.search(r'NSArray<NSDictionary \*> \*' + re.escape(name) + r' = @\[(.*?)\];', source, re.S)
    if not match:
        raise SystemExit('ERROR: missing server switch array: ' + name)
    return set(re.findall(r'@"key"\s*:\s*@"([^"]+)"', match.group(1)))

main_keys = keys_for_array('allSwitchRows')
free_keys = keys_for_array('freeSwitchRows')
premium_keys = keys_for_array('premiumSwitchRows')
admin_keys = keys_for_array('adminSwitchRows')
expected_main = {
    'Enabled', 'AdvancedDisplayEnforcement', 'FramePacing', 'AdvertiseSelectedRateToApps',
    'AdaptiveFPS', 'ThermalGuard', 'BackgroundReduction', 'ConflictGuard', 'StutterFix',
    'MetalLayerCompatibility', 'MetalFramebufferOnlyOptimization', 'AppStabilityFix',
    'ScreenRecordingFix', 'OverrideBlockedApps', 'BatterySaver', 'ChargingOptimization'
}
expected_free = {'FreeRenderSchedulerEnabled', 'FreeSmoothEngineEnabled', 'FreeTouchTuningEnabled', 'FreeAdaptiveCadenceEnabled', 'FreeThermalGuardEnabled', 'FreeCADisplayLinkHookEnabled'}
expected_premium = {'PremiumRenderSchedulerEnabled', 'PremiumTouchTuningEnabled', 'PremiumLowLatencyModeEnabled', 'PremiumThermalGuardEnabled', 'PremiumChargingGuardEnabled', 'PremiumTier4DisplayPolicyEnabled', 'PremiumCADisplayLinkHookEnabled'}
expected_admin = {
    'AdminRenderSchedulerEnabled', 'AdminTouchTuningEnabled', 'AdminFastScrollEnabled',
    'AdminHideScrollIndicatorsEnabled', 'AdminStaticSurfaceCacheEnabled', 'AdminThermalCooldownEnabled',
    'AdminLocalDaemonBridgeEnabled', 'AdminChargingCooldownEnabled',
    'AdminAdaptiveFramePacingEnabled', 'AdminDashboardLoadShedEnabled', 'AdminTitaniumHardwareRateAdapterEnabled', 'AdminCADisplayLinkHookEnabled', 'AdminHomeTransitionShieldEnabled'
}
if (main_keys != expected_main or free_keys != expected_free or
    premium_keys != expected_premium or admin_keys != expected_admin):
    raise SystemExit('ERROR: FREE/PREMIUM/ADMIN switch arrays do not match their server-specific schemas.')
for item in ['PMServerScopedConfigurationKeys', 'PMBuildDomainForServerChanges',
             'ServerProfiles', 'ServerProfilesSchemaVersion', 'ActiveServerMode',
             'prepareServerProfilesForLaunch', 'refreshActiveServerRuntime',
             'activateFreeOptimizationWithOptions:', 'activatePremiumOptimizationWithOptions:',
             'activateAdminOptimizationWithOptions:']:
    if item not in source:
        raise SystemExit('ERROR: separated server profile/runtime integration missing: ' + item)
if ('PMProtectedPasswordMatches' not in source or
    '9f981038884a60f27d6ef5cabb2ee3a721e52062d8622dc258f00f93ba63edee' not in source or
    'a5d149071723ad0ce570d322251c01d4c8229dd77b6308735813f71f4ac2b0b5' not in source):
    raise SystemExit('ERROR: separate Premium/Admin password digest gates are missing.')
for item in ['PMServerAdminSelectedMode', 'PMServerAdminAuthorizedInstallationID',
             'PMSetAdminSelectedMode', 'PMShouldAutoActivateAdmin', 'PMRememberAdminActivation',
             'PMAdminAuthorizationMatchesCurrentInstall', 'PMProtectedAuthAttemptAllowed',
             'PMRecordProtectedAuthFailure', 'serverAdminActive',
             'activateAdminOptimizationWithOptions:', 'applyAdminPreset:',
             'SERVER ADMIN', 'AdminRenderSchedulerEnabled', 'AdminTouchTuningEnabled',
             'AdminFastScrollEnabled', 'AdminHideScrollIndicatorsEnabled',
             'AdminStaticSurfaceCacheEnabled', 'AdminThermalCooldownEnabled',
             'AdminLocalDaemonBridgeEnabled', 'AdminChargingCooldownEnabled',
             'AdminAdaptiveFramePacingEnabled', 'AdminDashboardLoadShedEnabled']:
    if item not in source:
        raise SystemExit('ERROR: ADMIN server integration missing: ' + item)
engine_header = Path('ControlApp/PMPremiumOptimizationEngine.h').read_text(errors='replace')
engine_source = Path('ControlApp/PMPremiumOptimizationEngine.m').read_text(errors='replace')
bridge_source = Path('ControlApp/PMLocalBridge.m').read_text(errors='replace')
for item in ['@interface PMUltimatePowerEngine', 'deployMaximumPerformanceMode',
             'disengagePerformanceMode', 'optimizeTargetView:', 'refreshAdminOptimizationWithOptions:',
             'maximumVisitedViews = 4096', 'UIScrollViewDecelerationRateFast',
             'NSProcessInfoThermalStateSerious', 'NSProcessInfoThermalStateCritical',
             'deployMaximumPerformanceModeWithThermalCooldown:', 'chargingCooldown:',
             'updateAdminLocalBridgeWithOptions:', 'UIDeviceBatteryStateDidChangeNotification',
             'thermal_reduce', 'thermal_resume']:
    if item not in engine_header + '\n' + engine_source:
        raise SystemExit('ERROR: ADMIN engine integration missing: ' + item)
for forbidden in ['pthread_setschedparam', 'SCHED_FIFO', 'delaysTouchesBegan', 'delaysTouchesEnded',
                  'beginActivityWithOptions:0x00FFFFFF', 'popen(', 'setuid(0)']:
    if forbidden in engine_source:
        raise SystemExit('ERROR: unsafe global priority/root operation detected: ' + forbidden)
for item in ['PMServerPremiumPreviouslyActivated', 'PMServerPremiumAuthorizedInstallationID',
             'PMServerPremiumSelectedMode', 'PMRememberPremiumActivation',
             'PMPremiumAuthorizationMatchesCurrentInstall', 'PMShouldAutoActivatePremium',
             'PMSetPremiumSelectedMode(NO)', 'activateFreeOptimization', 'suspendOptimizations',
             'UIApplicationWillResignActiveNotification', 'UIApplicationDidEnterBackgroundNotification',
             'UIApplicationDidBecomeActiveNotification',
             'dlsym(RTLD_DEFAULT, \"PMControlTweakRuntimeMarker\")',
             'dlsym(RTLD_DEFAULT, \"PMControlTweakInstallationID\")']:
    if item not in source:
        raise SystemExit('ERROR: persistent Premium authorization / FREE fallback integration missing: ' + item)
if 'requestPremiumReauthenticationAfterDelay' in source or 'PMServerPremiumAutoResume' in source:
    raise SystemExit('ERROR: obsolete per-launch Premium reauthentication code remains.')
tweak_source = Path('Tweak.x').read_text(errors='replace')
if ('PMControlTweakRuntimeMarker' not in tweak_source or 'return 0x504D4354' not in tweak_source or
    'PMControlTweakInstallationID' not in tweak_source or
    '.com.dell.promotioncontrol.installation-id' not in tweak_source):
    raise SystemExit('ERROR: tweak presence/install identity exports are missing; FREE fallback must remain verifiable.')
for item in ['PMEffectivePreferencesForCurrentApp', 'AppProfiles', 'g_ServerPolicyFlags',
             'PMPolicyThermalGuard', 'PMPolicyLowLatency',
             'PMPolicyAdaptiveCadence', 'PMRateRangeForActiveServer',
             'PMDarwinPreferencesChanged', 'PMPreferencesForSelectedServer',
             'FreeCADisplayLinkHookEnabled', 'PremiumCADisplayLinkHookEnabled',
             'AdminCADisplayLinkHookEnabled', 'setPreferredFrameRateRange:',
             'setPreferredFramesPerSecond:', 'addToRunLoop:']:
    if item not in tweak_source:
        raise SystemExit('ERROR: server-specific runtime hook/policy integration missing: ' + item)
if ('PMThermalTargetCap' not in tweak_source or
    'NSProcessInfoThermalStateSerious' not in tweak_source or
    'NSProcessInfoThermalStateCritical' not in tweak_source):
    raise SystemExit('ERROR: server-specific rate hook lost mandatory hardware/thermal bounds.')
postinst_source = Path('layout/DEBIAN/postinst').read_text(errors='replace')
postrm_source = Path('layout/DEBIAN/postrm').read_text(errors='replace')
if '.com.dell.promotioncontrol.installation-id' not in postinst_source or 'dd if=/dev/urandom' not in postinst_source:
    raise SystemExit('ERROR: postinst does not create a random tweak install identity.')
if '.com.dell.promotioncontrol.installation-id' not in postrm_source or '"remove"' not in postrm_source or '"purge"' not in postrm_source:
    raise SystemExit('ERROR: postrm does not revoke tweak install identity on remove/purge.')
combined_runtime = source + '\n' + tweak_source + '\n' + bridge_source
if 'PMRootHelper' in combined_runtime or 'setuid(0)' in combined_runtime or 'popen(' in combined_runtime:
    raise SystemExit('ERROR: unsafe arbitrary root command helper must not ship in this build.')
if 'PMSystemOverviewViewController' in source or 'Kiểm tra tổng quan 15 giây' in source:
    raise SystemExit('ERROR: removed machine-overview / 15-second check UI reappeared.')
app_delegate = Path('ControlApp/PMAppDelegate.m').read_text(errors='replace')
if 'objectForInfoDictionaryKey:@"CFBundleShortVersionString"' not in app_delegate:
    raise SystemExit('ERROR: typing intro must use the version stamped into the app bundle.')
print('Verified isolated FREE/PREMIUM/ADMIN profiles, tier engines and policies, exact ControlApp CADisplayLink hook, thermal bounds, app-profile overlay, icons, and live config reload.')
LIVE_DASHBOARD_CHECK

# Keep the supplied snippet's unsupported/private hardware actions out of release builds.
# IOMobileFramebuffer selector writes are undocumented, device-specific and not a refresh-rate API.
if grep -Eq 'IOConnectCallScalarMethod[[:space:]]*\(' Tweak.x; then
    echo "ERROR: unsupported direct IOKit scalar driver write detected; use read-only capability diagnostics." >&2
    exit 1
fi
if grep -Eq '%hook[[:space:]]+SBDisplayManager|%init\(SpringBoardPrivateTier\)' Tweak.x; then
    echo "ERROR: private SpringBoard display-manager hook is not part of the supported runtime path." >&2
    exit 1
fi
if grep -Eq 'setenv[[:space:]]*\([[:space:]]*"CA_(DISABLE_VSYNC|FORCE_MAX_FPS)"' Tweak.x; then
    echo "ERROR: unsupported environment-variable V-Sync/FPS spoof detected." >&2
    exit 1
fi
if ! grep -Eq '^#define PM_BUILD_VERSION @"[0-9]+\.[0-9]+\.[0-9]+t"$' Tweak.x; then
    echo "ERROR: Tweak.x must define PM_BUILD_VERSION so runtime diagnostics match each build." >&2
    exit 1
fi
python3 - <<'FILTER_PREFLIGHT'
import plistlib
from pathlib import Path
with Path('ProMotionControl.plist').open('rb') as f:
    root = plistlib.load(f)
flt = root.get('Filter', {})
bundles = flt.get('Bundles', [])
classes = flt.get('Classes', [])
assert bundles == ['com.dell.promotioncontrol.app'], f'Expected only the control-app bundle, got: {bundles}'
assert not classes, f'Broad class-based injection is disabled in crash-containment release: {classes}'
print('Verified strict bundle-only injection: com.dell.promotioncontrol.app; no global UIKit class filter.')
FILTER_PREFLIGHT

# Ensure Debian maintainer scripts remain executable in the staged package.
chmod 755 "$0" layout/DEBIAN/postinst layout/DEBIAN/postrm

VERSION_FILE="VERSION"
CURRENT_VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
if [[ ! "$CURRENT_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+t$ ]]; then
    echo "Invalid VERSION: $CURRENT_VERSION" >&2
    exit 1
fi

# Exact version may be requested for reproducible release builds; otherwise retain auto-increment.
# The version stamping remains transactional: failed builds restore the original source metadata.
if [[ -n "${BUILD_VERSION_OVERRIDE:-}" ]]; then
    if [[ ! "$BUILD_VERSION_OVERRIDE" =~ ^[0-9]+\.[0-9]+\.[0-9]+t$ ]]; then
        echo "Invalid BUILD_VERSION_OVERRIDE: $BUILD_VERSION_OVERRIDE" >&2
        exit 1
    fi
    VERSION="$BUILD_VERSION_OVERRIDE"
else
    VERSION="$(python3 - "$CURRENT_VERSION" <<'PYVER'
import re, sys
m = re.fullmatch(r'(\d+)\.(\d+)\.(\d+)t', sys.argv[1])
if not m:
    raise SystemExit('Invalid version format')
major, minor, patch = map(int, m.groups())
if patch >= 99:
    minor += 1
    patch = 0
    if minor >= 100:
        major += 1
        minor = 0
else:
    patch += 1
print(f'{major}.{minor}.{patch}t')
PYVER
)"
fi
# Snapshot every file this script stamps before modifying it. The ACTIVE marker is
# written last so an interrupted snapshot is never mistaken for a build in progress.
mkdir -p "$RECOVERY_DIR/snapshot"
: > "$RECOVERY_DIR/FILES"
pm_snapshot_file() {
    local rel="$1"
    [[ -f "$rel" ]] || return 0
    if ! grep -Fxq "$rel" "$RECOVERY_DIR/FILES"; then
        mkdir -p "$RECOVERY_DIR/snapshot/$(dirname "$rel")"
        cp -p "$rel" "$RECOVERY_DIR/snapshot/$rel"
        printf '%s\n' "$rel" >> "$RECOVERY_DIR/FILES"
    fi
}
for rel in VERSION Tweak.x control README-build.txt; do pm_snapshot_file "$rel"; done
while IFS= read -r plist_path; do
    plist_path="${plist_path#./}"
    [[ "$plist_path" == .build-recovery/* || "$plist_path" == .theos/* || "$plist_path" == packages/* ]] && continue
    pm_snapshot_file "$plist_path"
done < <(find . -path './.build-recovery' -prune -o -path './.theos' -prune -o -path './packages' -prune -o -type f -name '*.plist' -print)
printf '%s\n' "$CURRENT_VERSION" > "$RECOVERY_DIR/PREVIOUS_VERSION"
printf '%s\n' "$VERSION" > "$RECOVERY_DIR/NEXT_VERSION"
touch "$RECOVERY_DIR/ACTIVE"
trap pm_on_exit EXIT

printf '%s\n' "$VERSION" > "$VERSION_FILE"
APP_VERSION="${VERSION%t}"

# Stamp the actual Logos source before invoking Theos so runtime diagnostics
# carry the same version as the Debian package and standalone app.
python3 - "$VERSION" <<'PYTWEAK'
import re, sys
from pathlib import Path
version = sys.argv[1]
p = Path("Tweak.x")
text = p.read_text(encoding="utf-8")
pattern = r'(?m)^#define PM_BUILD_VERSION @"[^"]+"$'
text2, count = re.subn(pattern, f'#define PM_BUILD_VERSION @"{version}"', text)
assert count == 1, f"Expected one PM_BUILD_VERSION marker in Tweak.x, found {count}"
p.write_text(text2, encoding="utf-8")
print(f"Stamped Tweak.x runtime version: {version}")
PYTWEAK

python3 - "$VERSION" "$APP_VERSION" <<'PY'
import plistlib, re, sys
from pathlib import Path
version, app_version = sys.argv[1:3]

def stamp_obj(obj):
    if isinstance(obj, dict):
        return {k: stamp_obj(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [stamp_obj(v) for v in obj]
    if isinstance(obj, str):
        return re.sub(r'\b\d+\.\d+\.\d+t\b', version, obj)
    return obj

for p in Path('.').rglob('*.plist'):
    if '.theos' in p.parts or 'packages' in p.parts or '.build-recovery' in p.parts:
        continue
    with p.open('rb') as f:
        obj = plistlib.load(f)
    obj = stamp_obj(obj)
    if p.as_posix().endswith('ControlApp/Resources/Info.plist'):
        # iOS bundle versions must be numeric, while the Debian package suffix is 't'.
        obj['CFBundleVersion'] = app_version
        obj['CFBundleShortVersionString'] = app_version
    with p.open('wb') as f:
        plistlib.dump(obj, f, fmt=plistlib.FMT_XML, sort_keys=False)

# Only update the Debian Version field and current-version note. Rewriting every
# version-shaped string would corrupt historical release notes and source comments.
control_path = Path("control")
control_text = control_path.read_text(encoding="utf-8")
control_text, control_count = re.subn(r"(?m)^Version:\s*.*$", f"Version: {version}", control_text)
assert control_count == 1, f"Expected one Version field in control, found {control_count}"
control_path.write_text(control_text, encoding="utf-8")

readme_path = Path("README-build.txt")
readme_text = readme_path.read_text(encoding="utf-8")
readme_text, readme_count = re.subn(
    r"(?m)^Current source package version:.*$",
    f"Current source package version: {version} (stamped in Tweak.x during this build).",
    readme_text,
)
if readme_count == 0:
    readme_text += f"\nCurrent source package version: {version} (stamped in Tweak.x during this build).\n"
readme_path.write_text(readme_text, encoding="utf-8")
print(f"Building ProMotion Control package {version} (iOS app version {app_version})")
PY
if ! grep -Fq "#define PM_BUILD_VERSION @\"$VERSION\"" Tweak.x; then
    echo "ERROR: Tweak.x runtime version does not match package VERSION=$VERSION" >&2
    exit 1
fi

# Preserve non-package files; remove only old .deb outputs so they cannot be
# mistaken for the artifact from this build.
mkdir -p packages
find packages -maxdepth 1 -type f -name "*${VERSION}*.deb" -delete

# Memory-conscious WSL mode: preserve incremental objects by default.
# Set CLEAN_OBJECTS=1 only when intentionally rebuilding from scratch.
if [[ "${CLEAN_OBJECTS:-0}" == "1" ]]; then
    echo "CLEAN_OBJECTS=1: removing generated objects"
    rm -rf .theos/obj
else
    echo "Keeping existing build objects for incremental, lower-memory builds."
fi

# Avoid the broken aggregate clean target by default. Opt in only when required.
if [[ "${CLEAN_BEFORE_BUILD:-0}" == "1" ]]; then
    echo "CLEAN_BEFORE_BUILD=1: running explicit clean"
    "$MAKE_BIN" -j1 clean
else
    echo "Skipping make clean to avoid the ControlApp rm -rf empty-target failure."
fi

# WSL_LOW_MEMORY_BUILD: serial make + no debug symbols; avoid full clean by default.
BUILD_LOG="${BUILD_LOG:-$PWD/build-last.log}"
# Use one job and avoid make -B, which needlessly forces every target to rebuild.
MAKEFLAGS=-j1 "$MAKE_BIN" -j1 DEBUG=0 package FINALPACKAGE=1 2>&1 | tee "$BUILD_LOG"

printf '\nBuilt packages:\n'
shopt -s nullglob
packages=(packages/*"$VERSION"*.deb)
if ((${#packages[@]} == 0)); then
    echo "Build finished without producing a .deb package." >&2
    exit 1
fi
for deb in "${packages[@]}"; do
    printf '%s\n' "$deb"
    if command -v dpkg-deb >/dev/null; then
        package_version="$(dpkg-deb -f "$deb" Package Version Architecture)"
        printf '%s\n' "$package_version"
        if ! dpkg-deb --info "$deb" >/dev/null; then
            echo "Invalid Debian package: $deb" >&2
            exit 1
        fi
        if [[ "$package_version" != *"$VERSION"* ]]; then
            echo "Package metadata version does not match $VERSION: $deb" >&2
            exit 1
        fi
        tmp_verify="$(mktemp -d)"
        PM_VERIFY_TMP="$tmp_verify"
        dpkg-deb -x "$deb" "$tmp_verify/root"
        dpkg-deb -e "$deb" "$tmp_verify/control"
        app_dir="$(find "$tmp_verify/root" -type d -path '*/Applications/ProMotionControl.app' -print -quit)"
        if [[ -z "$app_dir" ]]; then
            echo "Standalone app bundle missing from package: $deb" >&2
            echo "This package is not safe to install; expected ProMotionControl.app." >&2
            exit 1
        fi
        if find "$tmp_verify/root" -iname '*ProMotionControlPrefs*' -print -quit | grep -q .; then
            echo "Unexpected legacy Preferences bundle found in package: $deb" >&2
            exit 1
        fi
        tweak_dylib="$(find "$tmp_verify/root" -type f -name 'ProMotionControl.dylib' -print -quit)"
        if [[ -z "$tweak_dylib" ]]; then
            echo "Compiled ProMotionControl.dylib is missing from package: $deb" >&2
            exit 1
        fi
        if ! grep -aFq "$VERSION" "$tweak_dylib"; then
            echo "Compiled tweak does not contain stamped build version $VERSION: $tweak_dylib" >&2
            exit 1
        fi
        if ! grep -aFq "PMControlTweakRuntimeMarker" "$tweak_dylib"; then
            echo "Compiled tweak is missing the Premium runtime-presence marker: $tweak_dylib" >&2
            exit 1
        fi
        if ! grep -aFq "PMControlTweakInstallationID" "$tweak_dylib"; then
            echo "Compiled tweak is missing the per-install Premium identity export: $tweak_dylib" >&2
            exit 1
        fi
        python3 - "$app_dir" "$tmp_verify/control" <<'PYVERIFY'
import os, plistlib, re, sys
from pathlib import Path
app = Path(sys.argv[1])
control = Path(sys.argv[2])
info_path = app / "Info.plist"
exe = app / "ProMotionControlApp"
assert info_path.is_file(), f"Missing app Info.plist: {info_path}"
assert exe.is_file() and os.access(exe, os.X_OK), f"Missing/non-executable app binary: {exe}"
assert b"PMControlTweakRuntimeMarker" in exe.read_bytes(), "App binary missing tweak-presence lookup"
assert b"PMControlTweakInstallationID" in exe.read_bytes(), "App binary missing tweak-install identity lookup"
assert not (app / "ProMotionControlApp.dpkg-tmp").exists(), "Temporary dpkg executable found in app bundle"
with info_path.open("rb") as f:
    info = plistlib.load(f)
assert info.get("CFBundleIdentifier") == "com.dell.promotioncontrol.app", "Wrong app bundle ID"
assert info.get("CFBundleExecutable") == "ProMotionControlApp", "Wrong executable key"
assert info.get("CFBundlePackageType") == "APPL", "Wrong bundle package type"
assert info.get("CFBundleDisplayName") == "ProMotion Control", "Wrong app display name"
assert re.fullmatch(r"[0-9]+(\.[0-9]+){0,2}", str(info.get("CFBundleVersion", ""))), "CFBundleVersion must be numeric"
assert re.fullmatch(r"[0-9]+(\.[0-9]+){0,2}", str(info.get("CFBundleShortVersionString", ""))), "CFBundleShortVersionString must be numeric"
expected_icons = {
    "AppIcon60x60@2x.png": (120, 120),
    "AppIcon60x60@3x.png": (180, 180),
    "AppIcon76x76@2x.png": (152, 152),
}
for name, expected_size in expected_icons.items():
    icon = app / name
    assert icon.is_file() and icon.stat().st_size > 0, f"Missing app icon: {icon}"
    with icon.open("rb") as f:
        header = f.read(24)
    assert header[:8] == b"\x89PNG\r\n\x1a\n", f"App icon isn't a PNG: {name}"
    width = int.from_bytes(header[16:20], "big")
    height = int.from_bytes(header[20:24], "big")
    assert (width, height) == expected_size, f"Unexpected dimensions for {name}: {(width, height)}"
postinst = control / "postinst"
assert postinst.is_file() and os.access(postinst, os.X_OK), "Missing executable package postinst"
assert "uicache" in postinst.read_text(errors="replace"), "postinst doesn't register app icon"
assert ".com.dell.promotioncontrol.installation-id" in postinst.read_text(errors="replace"), "postinst doesn't create install identity"
postrm = control / "postrm"
assert postrm.is_file() and os.access(postrm, os.X_OK), "Missing executable package postrm"
postinst_text = postinst.read_text(errors="replace")
postrm_text = postrm.read_text(errors="replace")
assert "pm-backup-owned" in postinst_text and "pm-created" in postinst_text, "postinst missing Filza backup ownership tracking"
assert "pm-backup-owned" in postrm_text and "pm-created" in postrm_text, "postrm missing safe Filza restore/remove lifecycle"
print("Verified standalone app bundle, numeric iOS bundle version, icons, uicache and Filza backup/restore scripts.")
PYVERIFY
        rm -rf "$tmp_verify"
        PM_VERIFY_TMP=""
    fi
done

# Commit only after all checks pass. Keep old package files in the same folder
# for manual rollback; current build artifacts are the ones containing $VERSION.
rm -rf "$RECOVERY_DIR"
trap - EXIT
