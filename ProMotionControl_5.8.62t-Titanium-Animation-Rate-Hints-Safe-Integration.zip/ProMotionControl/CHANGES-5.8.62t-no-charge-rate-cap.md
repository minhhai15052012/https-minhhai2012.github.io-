# 5.8.62t — Preserve selected Hz/FPS while charging

- Removed the charging-only 30 FPS ceiling from the Tweak.x runtime path.
- Removed the charging-only ceiling from the shared FREE/PREMIUM/ADMIN governor.
- ADMIN local bridge no longer requests `thermal_reduce` solely because the device is charging.
- Charging Guard switches now affect only auxiliary dashboard/diagnostic sampling intervals, not selected display cadence.
- Charging state remains observable by the watchdog, but it does not lower selected Hz/FPS.
- Preserved native panel limits, Low Power Mode handling, actual thermal protections, and sustained-overload safeguards.
- Updated build preflight to reject any charger-only Hz/FPS cap.
- No CPU overclock, private clock control, or thermal-protection bypass was added.

The source baseline is 5.8.61t; `build-ubuntu.sh` will stamp 5.8.62t on the next successful build.
