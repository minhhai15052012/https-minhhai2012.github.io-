# ProMotion Control — Premium Runtime Engine

Source baseline: 5.8.48t. The successful transactional build stamps package/app/tweak version 5.8.49t.

## Premium-only integration

- Added `PMAdvancedOptimizer` to the standalone ControlApp target.
- The render loop requests a 60–120 Hz `CADisplayLink` range on iOS 15+, falls back to 60 FPS on older iOS, and uses `NSRunLoopCommonModes`.
- Premium activates the render loop only while the control app is active. Backgrounding, Low Power Mode, serious thermal pressure, or switching back to FREE stops it.
- Added `PMInputAndDisplayBooster` with scroll-touch tuning scoped to `UIScrollView` instances owned by the control app. Original `delaysContentTouches` values are restored when Premium is disabled.
- CPU telemetry's Mach query now runs on a serial utility queue; UIKit updates remain on the main queue. Dashboard sampling timer runs in common run-loop modes.

## Safety boundaries

- No `SCHED_FIFO`, real-time thread priority, global `UIGestureRecognizer` delay mutation, arbitrary root commands, or thermal/battery-throttle bypass is included.
- iOS and the physical display retain final control over actual refresh/FPS. `CADisplayLink` is a request, not an overclock or a guarantee of game FPS.
- The Logos tweak filter remains restricted to the standalone ProMotion Control app; third-party app hooks remain quarantined in this release.
