# 5.8.59t — Smooth / Pro / Titanium integration

- Added `PMSmoothEngineAdvanced` as the PREMIUM-facing adapter over the existing `PMAdvancedOptimizer` loop.
- Added `PMSmoothEnginePro` as the ADMIN-facing adapter over the existing `PMUltimatePowerEngine` / Nexus pipeline.
- Added `TitaniumAbsoluteUnlockEngine` as an ADMIN rate-request adapter preserving independent Hz and FPS selections.
- Added real callback timing (`lastFrameDelta`, estimated callback FPS) to the shared `PMPerformanceMonitor`; `PMSmoothEnginePro.stutterCount` reads its existing drop counter.
- Exposed the existing ADMIN display link for diagnostics instead of allocating a duplicate `CADisplayLink`.
- Removed artificial ADMIN/PREMIUM 60 FPS caps in the app-local requested maximum when charging or at Fair thermal state. Requests still clamp to the actual panel maximum; Low Power and Serious/Critical thermal conditions still suspend or reduce work.
- Kept touch tuning inside the ControlApp's own scroll views with restoration of original values.
- Kept the Logos filter restricted to `com.dell.promotioncontrol.app`.

## Not enabled

No SCHED_FIFO scheduling, global gesture-recognizer edits, emergency URL cache purges on frame drops, fake UIScreen/CADisplay hardware reporting, private CAWindowServerDisplay hooks, V-Sync bypass, or SpringBoard-wide injection is enabled. Those mechanisms do not unlock a physical refresh rate and can destabilize the UI/system process. The existing public CADisplayLink path remains the active implementation.

## Verification

ZIP integrity, shell syntax, plist parsing, API wiring and source-level integration checks completed. Theos was not installed in this build environment, so a package compile and on-device validation were not performed.
