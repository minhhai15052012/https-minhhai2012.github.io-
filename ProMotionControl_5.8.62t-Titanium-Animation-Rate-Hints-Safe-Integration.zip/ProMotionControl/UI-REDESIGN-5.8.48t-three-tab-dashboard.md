# Superseded UI notes

This earlier three-tab note is superseded by `UI-REDESIGN-5.8.48t-live-wave-dashboard.md`, which documents the current live-wave telemetry panel, responsive landscape/portrait switch board, 0.2-second sampling, and safety limitations.
