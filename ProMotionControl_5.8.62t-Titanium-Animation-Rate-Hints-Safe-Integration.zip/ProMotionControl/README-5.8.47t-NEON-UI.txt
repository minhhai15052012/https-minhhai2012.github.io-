ProMotionControl 5.8.47t — Ubuntu BuildKit

This project rebuilds the in-app Home screen to match the supplied dark / neon
purple references. Existing five tabs and detailed settings controllers remain.

Build from Ubuntu/WSL:

  cd /mnt/c/Users/DELL/Downloads
  mkdir -p ~/Projects
  if [ -d ~/Projects/ProMotionControl ]; then
    mv ~/Projects/ProMotionControl \
      ~/Projects/ProMotionControl-backup-$(date +%Y%m%d-%H%M%S)
  fi
  unzip -o "ProMotionControl_5.8.47t_Neon-Reference-UI_Safe-Isolation_Ubuntu.zip" -d ~/Projects
  cd ~/Projects/ProMotionControl
  export THEOS="$HOME/theos"
  export PACKAGE_SCHEME=rootless
  export MAKEFLAGS="-j1"
  ./run-build-ubuntu.sh

Source VERSION is 5.8.46t; the successful build wrapper stamps 5.8.47t.
Theos and a valid iPhoneOS SDK must be installed locally. This archive has
passed static source/configuration checks, but it has not been compiled here.

IMPORTANT CRASH-CONTAINMENT NOTE
The tweak is restricted to com.dell.promotioncontrol.app and runtime hooks
remain quarantined (disabled). Thus this release does not apply FPS hooks to
other apps. This reduces cross-app risk while the cause of earlier crashes is
being isolated; it is not a claim of universal crash-free operation.
