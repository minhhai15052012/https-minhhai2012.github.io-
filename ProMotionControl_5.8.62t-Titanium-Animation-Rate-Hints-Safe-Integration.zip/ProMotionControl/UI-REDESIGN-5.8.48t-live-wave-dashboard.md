# ProMotion Control 5.8.48t — Live Wave Dashboard

The latest dashboard patch follows the supplied reference: dark navy cards,
cyan neon accents, a hardware telemetry panel, a moving CPU waveform, and a
central switch board. Landscape places telemetry and switches side by side;
portrait stacks them vertically.

The waveform uses rolling Mach CPU-load samples and redraws every 0.2 seconds.
The dashboard shows saved FPS/Hz targets, measured ProMotion Control UI
CADisplayLink callback rate, estimated frame interval, CPU load, iOS thermal
state, and saved App Stability switch status. Sampling stops when Home is no
longer visible.

All 16 distinct global switch keys present in this source are gathered into
one dashboard panel. Per-app switches remain in each app's profile editor.
The existing 10–244 Hz/FPS sliders, three root tabs, installed-app discovery,
15-second overview, Bio/Discord links, and safety-first runtime quarantine are
preserved.

Important: the display does not claim unsupported hardware rates, third-party
game FPS, CPU clock speed, global RAM cleanup, or cross-app tweak injection.
The runtime quarantine stays intact to limit crash exposure. Respring is
explained in the About page but is not executed from the app.
