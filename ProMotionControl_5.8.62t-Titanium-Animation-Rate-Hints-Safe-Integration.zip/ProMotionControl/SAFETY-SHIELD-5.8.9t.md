# Safety Shield integration — source baseline 5.8.9t / next build 5.8.10t

- Adds a chained global Objective-C uncaught-exception handler for diagnostics.
- Appends exception name, reason, userInfo, call stack, timestamp, and main/background-thread indication to `/var/mobile/Library/Preferences/com.promotioncontrol.crash.log` when permitted; falls back to `NSTemporaryDirectory()` when sandbox permissions deny the primary path.
- Adds `PM_SAFE_TRY` for non-essential Objective-C side effects and uses it around optional private-hook installation/logging.
- Does not wrap every `%orig` call because swallowing host exceptions can leave application state inconsistent.
- No claim of 100% crash prevention: Objective-C handlers cannot intercept all SIGSEGV/memory corruption, watchdog exits, jetsam, or every native/C++ failure.
- The ZIP build script starts from `VERSION=5.8.9t` and should stamp `5.8.10t` on the next successful build.
