# ProMotion Control 5.8.59t — Titanium per-server integration

Source `VERSION`: 5.8.58t. The build script stamps 5.8.59t only after the
package succeeds validation.

- FREE: added `PMSmoothEngine` API as a single-DisplayLink facade over the
  existing FREE `PMUltimateOptimizer`; added `FreeSmoothEngineEnabled`.
- PREMIUM: integrated Titanium-style synchronized preference/profile
  resolution, independent FPS/Hz target resolution, and the safe Tier-4
  DisplayLink adapter; added `PremiumTier4DisplayPolicyEnabled`.
- ADMIN: added a device-aware Titanium rate adapter backed by the public
  CADisplayLink path; added `AdminTitaniumHardwareRateAdapterEnabled`.
- Added distinct target FPS and target Hz atomics so configured rates are
  resolved independently before mapping to a frame-rate range.
- App-specific named profiles and bundle-specific profiles are resolved in
  order; server authorization and global guard switches cannot be overridden
  by per-app data. `excludedApps` is honored.
- Added build preflight checks for the new classes, switches, policies and
  prohibited private-driver hooks.

The supplied fake display modes, infinite pixel clock, IOHID report interval
rewrites, private framebuffer/WindowServer hooks, forced-success driver returns,
V-Sync bypass and direct panel write calls are intentionally not activated.
They do not unlock a panel's physical refresh modes and can crash WindowServer
or SpringBoard. All rates are requests via public CADisplayLink APIs, bounded by
physical display capability and iOS power/thermal policy.

The installed Substrate filter remains restricted to
`com.dell.promotioncontrol.app`; no third-party app injection is claimed.
