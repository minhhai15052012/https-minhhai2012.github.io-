# ProMotion Control 5.8.54t — separate ADMIN auth and adaptive power guards

- ADMIN has its own install-bound authorization grant and password digest. It no longer inherits ADMIN access merely from Premium authorization.
- PREMIUM uses its existing password; ADMIN uses the newly requested separate password.
- Five failed attempts per protected tier trigger a 60-second retry delay.
- FREE remains the default and never prompts automatically. Protected tiers require a valid tweak runtime marker and matching installation identity.
- FREE/PREMIUM/ADMIN engines are mutually exclusive, app-scoped and respect Low Power Mode and iOS thermal state.
- Premium reduces auxiliary dashboard sampling frequency by about 35% at baseline; Admin targets at least 75%. Charging and Fair thermal pressure slow sampling further.
- Charging-aware display cadence caps auxiliary render loops at 60 while charging/Fair thermal pressure. Serious/Critical thermal state or Low Power Mode pauses auxiliary render loops.
- “Charging Guard” means reducing this app’s extra work while charging. It does not change charging current, voltage, or hardware fast-charge negotiation.
- The percentages describe auxiliary telemetry / workload scheduling in ProMotion Control, not guaranteed reductions in a game’s CPU/GPU use or system-wide thermal throttling. Third-party app injection remains isolated.
- The build script stamps the next package version 5.8.54t after a successful build; source VERSION is 5.8.53t.
