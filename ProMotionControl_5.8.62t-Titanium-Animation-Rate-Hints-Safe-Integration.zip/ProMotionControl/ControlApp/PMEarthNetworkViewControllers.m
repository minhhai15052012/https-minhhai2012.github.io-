#import "PMEarthNetworkViewControllers.h"
#import "PMPerformanceSuite.h"
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <Network/Network.h>
#import <SystemConfiguration/CaptiveNetwork.h>
#import <CoreLocation/CoreLocation.h>
#import <ifaddrs.h>
#import <arpa/inet.h>
#import <net/if.h>
#import <string.h>
#import <math.h>

#pragma mark - Shared local styling

static UIColor *PMMediaAccentColor(void) {
    if (@available(iOS 13.0, *)) return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        return traits.userInterfaceStyle == UIUserInterfaceStyleDark
            ? [UIColor colorWithRed:0.24 green:0.78 blue:1.0 alpha:1.0]
            : [UIColor colorWithRed:0.05 green:0.42 blue:0.78 alpha:1.0];
    }];
    return [UIColor colorWithRed:0.05 green:0.42 blue:0.78 alpha:1.0];
}

static UIButton *PMMediaButton(NSString *title, SEL action, id target) {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    button.layer.cornerRadius = 13.0;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = PMMediaAccentColor().CGColor;
    button.backgroundColor = [PMMediaAccentColor() colorWithAlphaComponent:0.12];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:PMMediaAccentColor() forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    button.contentEdgeInsets = UIEdgeInsetsMake(10.0, 12.0, 10.0, 12.0);
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:42.0].active = YES;
    return button;
}

static UILabel *PMEarthLabel(NSString *text, CGFloat size, UIFontWeight weight) {
    UILabel *label = [UILabel new];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = UIColor.labelColor;
    label.font = [UIFont monospacedSystemFontOfSize:size weight:weight];
    label.numberOfLines = 0;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.75;
    return label;
}

#pragma mark - Earth location and network diagnostics

@interface PMEarthViewController () <CLLocationManagerDelegate>
@property (nonatomic, strong) UIImageView *earthView;
@property (nonatomic, strong) UILabel *connectionLabel;
@property (nonatomic, strong) UILabel *latencyLabel;
@property (nonatomic, strong) UILabel *endpointLabel;
@property (nonatomic, strong) UILabel *tierLabel;
@property (nonatomic, strong) UILabel *locationLabel;
@property (nonatomic, strong) UILabel *rateTargetLabel;
@property (nonatomic, strong) UILabel *rateRuntimeLabel;
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, strong) NSTimer *rateTimer;
@property (nonatomic, strong) NSURLSessionDataTask *probeTask;
@property (nonatomic, strong) nw_path_monitor_t pathMonitor;
@property (nonatomic, strong) dispatch_queue_t pathQueue;
@property (nonatomic, copy) NSArray<NSString *> *probeEndpoints;
@property (nonatomic) BOOL probeInProgress;
@property (nonatomic) BOOL locationRequested;
@property (nonatomic) BOOL locationUpdatesActive;
@property (nonatomic) BOOL pageActive;
@property (nonatomic) CLLocation *lastLocation;
@end

@implementation PMEarthViewController

- (void)setupContent {
    [super setupContent];
    self.title = @"Trái đất";
    [self addHeaderWithEyebrow:@"EARTH POSITION & NETWORK" title:@"Trái đất · Vị trí & kết nối" subtitle:@"Mô phỏng quả địa cầu, hiển thị vị trí iPhone khi được cấp quyền và đo phản hồi mạng hiện tại."];

    UIStackView *earthCard = [self newCardWithTitle:@"BẢN ĐỒ TRÁI ĐẤT MÔ PHỎNG" subtitle:@"Hình ảnh địa cầu minh họa; vị trí GPS được hiển thị bằng tọa độ riêng bên dưới."];
    UIView *globeStage = [UIView new];
    globeStage.translatesAutoresizingMaskIntoConstraints = NO;
    [earthCard addArrangedSubview:globeStage];
    [globeStage.heightAnchor constraintEqualToConstant:238.0].active = YES;

    UIView *orbitRing = [UIView new];
    orbitRing.translatesAutoresizingMaskIntoConstraints = NO;
    orbitRing.userInteractionEnabled = NO;
    orbitRing.layer.cornerRadius = 108.0;
    orbitRing.layer.borderWidth = 1.0;
    orbitRing.layer.borderColor = [PMMediaAccentColor() colorWithAlphaComponent:0.42].CGColor;
    [globeStage addSubview:orbitRing];
    [NSLayoutConstraint activateConstraints:@[
        [orbitRing.widthAnchor constraintEqualToConstant:216.0],
        [orbitRing.heightAnchor constraintEqualToConstant:216.0],
        [orbitRing.centerXAnchor constraintEqualToAnchor:globeStage.centerXAnchor],
        [orbitRing.centerYAnchor constraintEqualToAnchor:globeStage.centerYAnchor]
    ]];

    UIImage *earthImage = [UIImage imageNamed:@"EarthGlobe"];
    if (!earthImage) earthImage = [UIImage systemImageNamed:@"globe.americas.fill"] ?: [UIImage systemImageNamed:@"globe"];
    self.earthView = [[UIImageView alloc] initWithImage:earthImage];
    self.earthView.translatesAutoresizingMaskIntoConstraints = NO;
    self.earthView.contentMode = UIViewContentModeScaleAspectFill;
    self.earthView.clipsToBounds = YES;
    self.earthView.layer.cornerRadius = 102.0;
    self.earthView.layer.borderWidth = 1.0;
    self.earthView.layer.borderColor = [PMMediaAccentColor() colorWithAlphaComponent:0.7].CGColor;
    self.earthView.layer.shadowColor = PMMediaAccentColor().CGColor;
    self.earthView.layer.shadowOpacity = 0.24;
    self.earthView.layer.shadowRadius = 14.0;
    [globeStage addSubview:self.earthView];
    [NSLayoutConstraint activateConstraints:@[
        [self.earthView.widthAnchor constraintEqualToConstant:204.0],
        [self.earthView.heightAnchor constraintEqualToConstant:204.0],
        [self.earthView.centerXAnchor constraintEqualToAnchor:globeStage.centerXAnchor],
        [self.earthView.centerYAnchor constraintEqualToAnchor:globeStage.centerYAnchor]
    ]];

    UIView *locationBar = [UIView new];
    locationBar.translatesAutoresizingMaskIntoConstraints = NO;
    locationBar.backgroundColor = [PMMediaAccentColor() colorWithAlphaComponent:0.10];
    locationBar.layer.cornerRadius = 13.0;
    locationBar.layer.borderWidth = 1.0;
    locationBar.layer.borderColor = [PMMediaAccentColor() colorWithAlphaComponent:0.55].CGColor;
    UIStackView *locationContent = [[UIStackView alloc] initWithFrame:CGRectZero];
    locationContent.translatesAutoresizingMaskIntoConstraints = NO;
    locationContent.axis = UILayoutConstraintAxisHorizontal;
    locationContent.alignment = UIStackViewAlignmentCenter;
    locationContent.spacing = 9.0;
    UIImageView *locationGlyph = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"location.fill"]];
    locationGlyph.translatesAutoresizingMaskIntoConstraints = NO;
    locationGlyph.tintColor = PMMediaAccentColor();
    locationGlyph.contentMode = UIViewContentModeScaleAspectFit;
    [locationGlyph.widthAnchor constraintEqualToConstant:18.0].active = YES;
    [locationGlyph.heightAnchor constraintEqualToConstant:18.0].active = YES;
    self.locationLabel = PMEarthLabel(@"iPhone của bạn: chưa xác định vị trí", 12.0, UIFontWeightSemibold);
    self.locationLabel.numberOfLines = 1;
    [locationContent addArrangedSubview:locationGlyph];
    [locationContent addArrangedSubview:self.locationLabel];
    [locationBar addSubview:locationContent];
    [NSLayoutConstraint activateConstraints:@[
        [locationContent.leadingAnchor constraintEqualToAnchor:locationBar.leadingAnchor constant:12.0],
        [locationContent.trailingAnchor constraintEqualToAnchor:locationBar.trailingAnchor constant:-12.0],
        [locationContent.topAnchor constraintEqualToAnchor:locationBar.topAnchor constant:9.0],
        [locationContent.bottomAnchor constraintEqualToAnchor:locationBar.bottomAnchor constant:-9.0],
        [locationBar.heightAnchor constraintGreaterThanOrEqualToConstant:42.0]
    ]];
    self.connectionLabel = PMEarthLabel(@"Trạng thái mạng: đang kiểm tra…", 13.0, UIFontWeightSemibold);
    self.latencyLabel = PMEarthLabel(@"Độ trễ HTTPS: chưa đo", 16.0, UIFontWeightBold);
    self.endpointLabel = PMEarthLabel(@"Máy chủ kiểm tra: —", 12.0, UIFontWeightMedium);
    self.tierLabel = PMEarthLabel(@"SERVER: —", 12.0, UIFontWeightMedium);
    self.rateTargetLabel = PMEarthLabel(@"Mục tiêu đã chọn: —", 13.0, UIFontWeightSemibold);
    self.rateRuntimeLabel = PMEarthLabel(@"Giới hạn màn hình / FPS callback: —", 12.0, UIFontWeightMedium);
    [earthCard addArrangedSubview:locationBar];
    [earthCard addArrangedSubview:self.connectionLabel];
    [earthCard addArrangedSubview:self.latencyLabel];
    [earthCard addArrangedSubview:self.endpointLabel];
    [earthCard addArrangedSubview:self.tierLabel];
    [earthCard addArrangedSubview:self.rateTargetLabel];
    [earthCard addArrangedSubview:self.rateRuntimeLabel];

    UIStackView *actions = [self newCardWithTitle:@"ĐỊNH VỊ VÀ KIỂM TRA" subtitle:@"Vị trí chỉ được đọc sau khi bạn cấp quyền iOS; có thể cập nhật bằng nút này. GPS và kiểm tra mạng chỉ chạy khi trang Trái đất đang mở."];
    [actions addArrangedSubview:PMMediaButton(@"Cập nhật vị trí iPhone", @selector(requestDeviceLocation), self)];
    [actions addArrangedSubview:PMMediaButton(@"Đo độ trễ mạng / Apple", @selector(runEarthProbe), self)];
    [actions addArrangedSubview:PMMediaButton(@"Mở Cloudflare 1.1.1.1 / WARP", @selector(openCloudflareOne), self)];
    [self addNote:@"Thanh vị trí duy nhất hiển thị tọa độ iPhone khi bạn cấp quyền Vị trí khi dùng; độ chính xác phụ thuộc cài đặt GPS của iOS. GPS không tự giảm ping và không điều khiển vệ tinh hoặc máy chủ Apple. Ứng dụng chỉ kiểm tra phản hồi HTTPS công khai của Apple/Cloudflare và một số endpoint kết nối; không thể can thiệp tuyến mạng, modem, nhà mạng hay vệ tinh để tăng tốc toàn hệ thống. Ba server là ba profile lựa chọn loại trừ lẫn nhau: chỉ profile đang chọn được chạy, theo đúng công tắc của profile đó. Khi ứng dụng ra nền hoặc bị đóng, iOS có thể tạm dừng/ kết thúc tiến trình; không có chế độ refresh liên tục sau force-quit." toStack:self.contentStack];

    self.probeEndpoints = @[
        @"https://1.1.1.1/cdn-cgi/trace",
        @"https://www.cloudflare.com/cdn-cgi/trace",
        @"https://www.google.com/generate_204",
        @"https://connectivitycheck.gstatic.com/generate_204",
        @"https://www.apple.com/library/test/success.html",
        @"https://captive.apple.com/hotspot-detect.html"
    ];
    self.locationManager = [CLLocationManager new];
    self.locationManager.delegate = self;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    self.locationManager.distanceFilter = kCLDistanceFilterNone;

    self.pathQueue = dispatch_queue_create("com.dell.promotioncontrol.earth-path", DISPATCH_QUEUE_SERIAL);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(earthApplicationDidEnterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(earthApplicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(earthSystemPolicyChanged:) name:NSProcessInfoThermalStateDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(earthSystemPolicyChanged:) name:NSProcessInfoPowerStateDidChangeNotification object:nil];
    [self updateSelectedTierAndRates];
    [self updateLocationAuthorizationLabel];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.pageActive = YES;
    [self startEarthUpdates];
    [self updateSelectedTierAndRates];
    [self updateLocationAuthorizationLabel];
    CLAuthorizationStatus authorization = CLLocationManager.authorizationStatus;
    if (authorization == kCLAuthorizationStatusNotDetermined) {
        self.locationRequested = YES;
        [self.locationManager requestWhenInUseAuthorization];
    } else if (authorization == kCLAuthorizationStatusAuthorizedWhenInUse || authorization == kCLAuthorizationStatusAuthorizedAlways) {
        self.locationRequested = YES;
        [self startForegroundLocationUpdates];
        self.locationLabel.text = @"iPhone của bạn: đang xác định vị trí…";
    }
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self runEarthProbe];
}

- (void)viewWillDisappear:(BOOL)animated {
    self.pageActive = NO;
    [self stopEarthUpdates];
    [self stopForegroundLocationUpdates];
    self.locationRequested = NO;
    [super viewWillDisappear:animated];
}

- (void)startForegroundLocationUpdates {
    if (!self.pageActive || !self.locationRequested || ![CLLocationManager locationServicesEnabled]) return;
    CLAuthorizationStatus authorization = CLLocationManager.authorizationStatus;
    if (authorization != kCLAuthorizationStatusAuthorizedWhenInUse && authorization != kCLAuthorizationStatusAuthorizedAlways) return;
    if (!self.locationUpdatesActive) {
        [self.locationManager startUpdatingLocation];
        self.locationUpdatesActive = YES;
    }
}

- (void)stopForegroundLocationUpdates {
    if (!self.locationUpdatesActive) return;
    [self.locationManager stopUpdatingLocation];
    self.locationUpdatesActive = NO;
}

- (void)earthApplicationDidEnterBackground:(NSNotification *)note {
    (void)note;
    self.pageActive = NO;
    [self stopEarthUpdates];
    [self stopForegroundLocationUpdates];
}

- (void)earthApplicationDidBecomeActive:(NSNotification *)note {
    (void)note;
    BOOL visible = self.isViewLoaded && self.view.window &&
        self.navigationController.topViewController == self &&
        self.tabBarController.selectedViewController == self.navigationController;
    if (!visible) return;
    self.pageActive = YES;
    [self startEarthUpdates];
    if (self.locationRequested) [self startForegroundLocationUpdates];
    [self runEarthProbe];
}

- (void)earthSystemPolicyChanged:(NSNotification *)note {
    (void)note;
    if (!self.pageActive) return;
    [self updateEarthRefreshPolicy];
}

- (void)startEarthUpdates {
    [self startPathMonitor];
    if (self.earthView.layer.animationKeys.count == 0) {
        CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        rotation.fromValue = @0.0;
        rotation.toValue = @(M_PI * 2.0);
        rotation.duration = 36.0;
        rotation.repeatCount = HUGE_VALF;
        rotation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
        [self.earthView.layer addAnimation:rotation forKey:@"pm.earth.continuousRotation"];
    }
    [self updateEarthRefreshPolicy];
}

- (void)updateEarthRefreshPolicy {
    if (!self.pageActive) return;
    NSProcessInfo *processInfo = NSProcessInfo.processInfo;
    NSProcessInfoThermalState thermal = NSProcessInfoThermalStateNominal;
    if (@available(iOS 11.0, *)) thermal = processInfo.thermalState;

    // Refresh network diagnostics only while foregrounded, with a longer
    // interval under heat/Low Power Mode and no automatic probes at Critical.
    NSTimeInterval probeInterval = 20.0;
    NSTimeInterval statusInterval = 3.0;
    if (processInfo.isLowPowerModeEnabled || thermal == NSProcessInfoThermalStateFair) {
        probeInterval = 45.0;
        statusInterval = 5.0;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
        self.locationManager.distanceFilter = 500.0;
        [self startForegroundLocationUpdates];
    } else if (thermal == NSProcessInfoThermalStateSerious) {
        probeInterval = 90.0;
        statusInterval = 8.0;
        [self stopForegroundLocationUpdates];
    } else if (thermal == NSProcessInfoThermalStateCritical) {
        probeInterval = 0.0;
        statusInterval = 12.0;
        [self stopForegroundLocationUpdates];
    } else {
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        self.locationManager.distanceFilter = 100.0;
        [self startForegroundLocationUpdates];
    }

    NSTimeInterval currentProbe = self.refreshTimer ? self.refreshTimer.timeInterval : -1.0;
    if (fabs(currentProbe - probeInterval) > 0.5) {
        [self.refreshTimer invalidate];
        self.refreshTimer = nil;
        if (probeInterval > 0.0) {
            self.refreshTimer = [NSTimer timerWithTimeInterval:probeInterval
                target:self selector:@selector(runEarthProbe) userInfo:nil repeats:YES];
            self.refreshTimer.tolerance = MIN(5.0, probeInterval * 0.15);
            [NSRunLoop.mainRunLoop addTimer:self.refreshTimer forMode:NSRunLoopCommonModes];
        }
    }

    NSTimeInterval currentStatus = self.rateTimer ? self.rateTimer.timeInterval : -1.0;
    if (fabs(currentStatus - statusInterval) > 0.5) {
        [self.rateTimer invalidate];
        self.rateTimer = [NSTimer timerWithTimeInterval:statusInterval
            target:self selector:@selector(refreshEarthStatus) userInfo:nil repeats:YES];
        self.rateTimer.tolerance = MIN(2.0, statusInterval * 0.15);
        [NSRunLoop.mainRunLoop addTimer:self.rateTimer forMode:NSRunLoopCommonModes];
    }
}

- (void)refreshEarthStatus {
    if (!self.pageActive) return;
    [self updateSelectedTierAndRates];
    [self updateEarthRefreshPolicy];
}

- (void)stopEarthUpdates {
    [self.refreshTimer invalidate];
    self.refreshTimer = nil;
    [self.rateTimer invalidate];
    self.rateTimer = nil;
    [self.probeTask cancel];
    self.probeTask = nil;
    self.probeInProgress = NO;
    [self.earthView.layer removeAnimationForKey:@"pm.earth.continuousRotation"];
    [self stopPathMonitor];
}

- (void)startPathMonitor {
    if (self.pathMonitor) return;
    self.pathMonitor = nw_path_monitor_create();
    if (!self.pathMonitor) return;
    __weak typeof(self) weakSelf = self;
    nw_path_monitor_set_update_handler(self.pathMonitor, ^(nw_path_t path) {
        nw_path_status_t pathStatus = nw_path_get_status(path);
        NSString *status = pathStatus == nw_path_status_satisfied ? @"Đã kết nối" :
            (pathStatus == nw_path_status_satisfiable ? @"Có thể kết nối" : @"Mất kết nối");
        NSString *interface = nw_path_uses_interface_type(path, nw_interface_type_wifi) ? @"Wi‑Fi" :
            (nw_path_uses_interface_type(path, nw_interface_type_cellular) ? @"Di động" :
             (nw_path_uses_interface_type(path, nw_interface_type_wired) ? @"Ethernet" : @"Khác"));
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (self && self.pageActive && self.isViewLoaded) {
                self.connectionLabel.text = [NSString stringWithFormat:@"Trạng thái mạng: %@ · %@", status, interface];
            }
        });
    });
    nw_path_monitor_set_queue(self.pathMonitor, self.pathQueue);
    nw_path_monitor_start(self.pathMonitor);
}

- (void)stopPathMonitor {
    if (!self.pathMonitor) return;
    nw_path_monitor_cancel(self.pathMonitor);
    self.pathMonitor = nil;
}

- (void)requestDeviceLocation {
    CLAuthorizationStatus status = CLLocationManager.authorizationStatus;
    if (status == kCLAuthorizationStatusNotDetermined) {
        self.locationRequested = YES;
        [self.locationManager requestWhenInUseAuthorization];
    } else if (status == kCLAuthorizationStatusAuthorizedWhenInUse || status == kCLAuthorizationStatusAuthorizedAlways) {
        self.locationRequested = YES;
        [self startForegroundLocationUpdates];
        self.locationLabel.text = @"iPhone của bạn: đang xác định vị trí…";
    } else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Cần quyền vị trí" message:@"Bật quyền Vị trí khi dùng trong Cài đặt iOS để hiển thị tọa độ trên trang Trái đất. Tọa độ chỉ hiển thị trong ứng dụng và không được gửi tới máy chủ đo mạng." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
        [alert addAction:[UIAlertAction actionWithTitle:@"Mở Cài đặt" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            NSURL *settingsURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if (settingsURL && [UIApplication.sharedApplication canOpenURL:settingsURL]) [UIApplication.sharedApplication openURL:settingsURL options:@{} completionHandler:nil];
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)updateLocationAuthorizationLabel {
    CLAuthorizationStatus status = CLLocationManager.authorizationStatus;
    if (status == kCLAuthorizationStatusDenied || status == kCLAuthorizationStatusRestricted) {
        self.locationLabel.text = @"iPhone của bạn: quyền vị trí bị từ chối";
    } else if (status == kCLAuthorizationStatusNotDetermined) {
        self.locationLabel.text = @"iPhone của bạn: nhấn Cập nhật vị trí";
    } else if (!self.lastLocation) {
        self.locationLabel.text = @"iPhone của bạn: đã cấp quyền · đang chờ GPS";
    }
}

- (void)locationManagerDidChangeAuthorization:(CLLocationManager *)manager {
    (void)manager;
    [self updateLocationAuthorizationLabel];
    if (self.pageActive && self.locationRequested && (CLLocationManager.authorizationStatus == kCLAuthorizationStatusAuthorizedWhenInUse || CLLocationManager.authorizationStatus == kCLAuthorizationStatusAuthorizedAlways)) {
        [self startForegroundLocationUpdates];
    }
    if (CLLocationManager.authorizationStatus == kCLAuthorizationStatusDenied || CLLocationManager.authorizationStatus == kCLAuthorizationStatusRestricted) {
        self.locationRequested = NO;
        [self stopForegroundLocationUpdates];
    }
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    (void)manager;
    (void)status;
    [self locationManagerDidChangeAuthorization:self.locationManager];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    (void)manager;
    CLLocation *location = locations.lastObject;
    if (![location isKindOfClass:[CLLocation class]] || location.horizontalAccuracy < 0.0) return;
    self.lastLocation = location;
    self.locationLabel.text = [NSString stringWithFormat:@"iPhone: %.5f° %@, %.5f° %@ · ±%.0f m",
        fabs(location.coordinate.latitude), location.coordinate.latitude >= 0.0 ? @"Bắc" : @"Nam",
        fabs(location.coordinate.longitude), location.coordinate.longitude >= 0.0 ? @"Đông" : @"Tây",
        location.horizontalAccuracy];
    // Keep this one location bar fresh while the Earth page is visible; updates stop on page/app background.
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    (void)manager;
    if (error.code == kCLErrorLocationUnknown) return;
    self.locationLabel.text = [NSString stringWithFormat:@"iPhone của bạn: %@", error.localizedDescription ?: @"không xác định được"];
    self.locationRequested = NO;
    [self stopForegroundLocationUpdates];
}

- (NSDictionary *)selectedServerPreferences {
    NSDictionary *root = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/Preferences/com.dell.promotioncontrol.plist"] ?: @{};
    NSInteger mode = [root[@"ActiveServerMode"] respondsToSelector:@selector(integerValue)] ? MIN(MAX([root[@"ActiveServerMode"] integerValue], 0), 2) : 0;
    NSString *profileName = mode == 2 ? @"ADMIN" : (mode == 1 ? @"PREMIUM" : @"FREE");
    NSDictionary *profiles = [root[@"ServerProfiles"] isKindOfClass:[NSDictionary class]] ? root[@"ServerProfiles"] : @{};
    NSDictionary *profile = [profiles[profileName] isKindOfClass:[NSDictionary class]] ? profiles[profileName] : @{};
    NSMutableDictionary *merged = [root mutableCopy];
    [merged addEntriesFromDictionary:profile];
    merged[@"ActiveServerMode"] = @(mode);
    return [merged copy];
}

- (NSInteger)configuredRateForPreferences:(NSDictionary *)prefs modeKey:(NSString *)modeKey customKey:(NSString *)customKey enabledKey:(NSString *)enabledKey {
    if (![prefs[enabledKey] respondsToSelector:@selector(boolValue)] || ![prefs[enabledKey] boolValue]) return 0;
    NSInteger mode = [prefs[modeKey] respondsToSelector:@selector(integerValue)] ? [prefs[modeKey] integerValue] : 0;
    if (mode == -1) return [prefs[customKey] respondsToSelector:@selector(integerValue)] ? MIN(MAX([prefs[customKey] integerValue], 10), 244) : 60;
    return mode > 0 ? MIN(MAX(mode, 10), 244) : 0;
}

- (void)updateSelectedTierAndRates {
    NSDictionary *prefs = [self selectedServerPreferences];
    NSInteger mode = [prefs[@"ActiveServerMode"] respondsToSelector:@selector(integerValue)] ? [prefs[@"ActiveServerMode"] integerValue] : 0;
    NSString *tier = mode == 2 ? @"ADMIN" : (mode == 1 ? @"PREMIUM" : @"FREE");
    BOOL masterEnabled = [prefs[@"Enabled"] respondsToSelector:@selector(boolValue)] && [prefs[@"Enabled"] boolValue];
    NSString *schedulerKey = mode == 2 ? @"AdminRenderSchedulerEnabled" : (mode == 1 ? @"PremiumRenderSchedulerEnabled" : @"FreeRenderSchedulerEnabled");
    NSString *hookKey = mode == 2 ? @"AdminCADisplayLinkHookEnabled" : (mode == 1 ? @"PremiumCADisplayLinkHookEnabled" : @"FreeCADisplayLinkHookEnabled");
    BOOL schedulerEnabled = !prefs[schedulerKey] || [prefs[schedulerKey] boolValue];
    BOOL hookEnabled = !prefs[hookKey] || [prefs[hookKey] boolValue];
    NSInteger hz = [self configuredRateForPreferences:prefs modeKey:@"RefreshMode" customKey:@"CustomRefreshRate" enabledKey:@"RefreshRateEnabled"];
    NSInteger fps = [self configuredRateForPreferences:prefs modeKey:@"FPSMode" customKey:@"CustomFPS" enabledKey:@"FPSOverrideEnabled"];
    BOOL framePacing = !prefs[@"FramePacing"] || [prefs[@"FramePacing"] boolValue];
    BOOL enforcement = !prefs[@"AdvancedDisplayEnforcement"] || [prefs[@"AdvancedDisplayEnforcement"] boolValue];
    BOOL runtimeEnabled = masterEnabled && schedulerEnabled && hookEnabled && framePacing && enforcement && (hz > 0 || fps > 0);
    self.tierLabel.text = [NSString stringWithFormat:@"SERVER đang chọn: %@ · %@", tier, runtimeEnabled ? @"CÔNG TẮC ĐANG BẬT" : @"ĐANG TẮT / CHƯA ĐỦ ĐIỀU KIỆN"];
    NSString *hzText = hz > 0 ? [NSString stringWithFormat:@"%ld Hz", (long)hz] : @"AUTO Hz";
    NSString *fpsText = fps > 0 ? [NSString stringWithFormat:@"%ld FPS", (long)fps] : @"AUTO FPS";
    self.rateTargetLabel.text = [NSString stringWithFormat:@"Mục tiêu đã chọn: %@ / %@", hzText, fpsText];
    NSInteger physicalMax = (NSInteger)UIScreen.mainScreen.maximumFramesPerSecond;
    if (physicalMax <= 0) physicalMax = 60;
    CGFloat measured = [PMPerformanceMonitor sharedMonitor].measuredFramesPerSecond;
    NSString *measuredText = measured > 0.0 ? [NSString stringWithFormat:@"%.0f callback FPS", measured] : @"đang lấy mẫu callback";
    self.rateRuntimeLabel.text = [NSString stringWithFormat:@"Màn hình tối đa báo cáo: %ld Hz · %@", (long)physicalMax, measuredText];
}

- (void)runEarthProbe {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self runEarthProbe]; });
        return;
    }
    if (self.probeInProgress || self.probeEndpoints.count == 0 || !self.pageActive) return;
    self.probeInProgress = YES;
    [self.probeTask cancel];
    NSUInteger index = arc4random_uniform((uint32_t)self.probeEndpoints.count);
    NSString *endpoint = self.probeEndpoints[index];
    self.endpointLabel.text = [NSString stringWithFormat:@"Endpoint kiểm tra: %@", [NSURL URLWithString:endpoint].host ?: endpoint];
    self.latencyLabel.text = @"Độ trễ HTTPS: đang đo…";
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:endpoint]
        cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:7.0];
    request.HTTPMethod = @"GET";
    request.HTTPShouldHandleCookies = NO;
    NSTimeInterval start = NSProcessInfo.processInfo.systemUptime;
    __weak typeof(self) weakSelf = self;
    self.probeTask = [NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(__unused NSData *data, NSURLResponse *response, NSError *error) {
        NSTimeInterval elapsed = (NSProcessInfo.processInfo.systemUptime - start) * 1000.0;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self) return;
            self.probeInProgress = NO;
            self.probeTask = nil;
            if (!self.pageActive) return;
            if (error || ![response isKindOfClass:[NSHTTPURLResponse class]]) {
                self.latencyLabel.text = [NSString stringWithFormat:@"Độ trễ HTTPS: không đo được · %@", error.localizedDescription ?: @"không có phản hồi"];
            } else {
                NSInteger status = ((NSHTTPURLResponse *)response).statusCode;
                self.latencyLabel.text = [NSString stringWithFormat:@"Độ trễ HTTPS: %.0f ms · HTTP %ld", elapsed, (long)status];
            }
        });
    }];
    [self.probeTask resume];
}

- (void)openCloudflareOne {
    NSURL *url = [NSURL URLWithString:@"https://one.one.one.one/"];
    if (url) [UIApplication.sharedApplication openURL:url options:@{} completionHandler:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self stopEarthUpdates];
    [self stopForegroundLocationUpdates];
    self.locationManager.delegate = nil;
    [self stopPathMonitor];
}

@end

#pragma mark - Network information / latency

static NSDictionary *PMReadNetworkInterfaces(void) {
    struct ifaddrs *interfaces = NULL;
    if (getifaddrs(&interfaces) != 0 || !interfaces) return @{};
    NSMutableDictionary<NSString *, NSMutableDictionary *> *records = [NSMutableDictionary dictionary];
    for (struct ifaddrs *cursor = interfaces; cursor; cursor = cursor->ifa_next) {
        if (!cursor->ifa_addr || !(cursor->ifa_flags & IFF_UP) || (cursor->ifa_flags & IFF_LOOPBACK)) continue;
        int family = cursor->ifa_addr->sa_family;
        if (family != AF_INET && family != AF_INET6) continue;
        NSString *name = [NSString stringWithUTF8String:cursor->ifa_name ?: ""];
        if (name.length == 0) continue;
        NSMutableDictionary *entry = records[name] ?: [NSMutableDictionary dictionary];
        char host[INET6_ADDRSTRLEN] = {0};
        const void *address = family == AF_INET
            ? (const void *)&((struct sockaddr_in *)cursor->ifa_addr)->sin_addr
            : (const void *)&((struct sockaddr_in6 *)cursor->ifa_addr)->sin6_addr;
        if (inet_ntop(family, address, host, sizeof(host))) {
            NSString *value = [NSString stringWithUTF8String:host];
            if (family == AF_INET) entry[@"IPv4"] = value;
            else entry[@"IPv6"] = value;
        }
        records[name] = entry;
    }
    freeifaddrs(interfaces);

    NSArray<NSString *> *priority = @[@"en0", @"en1", @"pdp_ip0", @"utun0", @"awdl0"];
    NSString *selectedName = nil;
    for (NSString *candidate in priority) {
        if (records[candidate].count > 0) { selectedName = candidate; break; }
    }
    if (!selectedName) selectedName = records.allKeys.firstObject;
    if (!selectedName) return @{};
    NSMutableDictionary *result = [records[selectedName] mutableCopy];
    result[@"Interface"] = selectedName;
    if ([selectedName hasPrefix:@"en"]) result[@"Kind"] = @"Wi‑Fi / Ethernet";
    else if ([selectedName hasPrefix:@"pdp"]) result[@"Kind"] = @"Mạng di động";
    else if ([selectedName hasPrefix:@"utun"]) result[@"Kind"] = @"VPN / Tunnel";
    else result[@"Kind"] = @"Mạng khác";
    return [result copy];
}

static NSString *PMReadCurrentWiFiSSID(void) {
    CFArrayRef supported = CNCopySupportedInterfaces();
    if (!supported) return nil;
    NSArray *interfaces = CFBridgingRelease(supported);
    for (id rawName in interfaces) {
        if (![rawName isKindOfClass:[NSString class]]) continue;
        CFDictionaryRef infoRef = CNCopyCurrentNetworkInfo((__bridge CFStringRef)rawName);
        if (!infoRef) continue;
        NSDictionary *info = CFBridgingRelease(infoRef);
        id ssid = info[(__bridge NSString *)kCNNetworkInfoKeySSID];
        if ([ssid isKindOfClass:[NSString class]] && [ssid length] > 0) return [ssid copy];
    }
    return nil;
}

@interface PMNetworkViewController () <CLLocationManagerDelegate>
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (nonatomic, strong) UILabel *networkNameLabel;
@property (nonatomic, strong) UILabel *interfaceLabel;
@property (nonatomic, strong) UILabel *ipv4Label;
@property (nonatomic, strong) UILabel *ipv6Label;
@property (nonatomic, strong) UILabel *publicIPLabel;
@property (nonatomic, strong) UILabel *latencyLabel;
@property (nonatomic, strong) UILabel *updatedLabel;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, strong) NSURLSessionDataTask *latencyTask;
@property (nonatomic) BOOL refreshInProgress;
@property (nonatomic) BOOL locationPermissionRequested;
@end

@implementation PMNetworkViewController

- (void)setupContent {
    [super setupContent];
    self.title = @"Mạng";
    [self addHeaderWithEyebrow:@"NETWORK STATUS" title:@"Hệ thống mạng" subtitle:@"Thông tin kết nối hiện tại của iPhone, chỉ đọc tại thiết bị."];

    UIStackView *connectionCard = [self newCardWithTitle:@"KẾT NỐI ĐANG DÙNG" subtitle:@"Tên Wi‑Fi, giao diện mạng và địa chỉ IP nội bộ."];
    self.networkNameLabel = [self networkValueLabel:@"Đang kiểm tra tên mạng…"];
    self.interfaceLabel = [self networkValueLabel:@"Giao diện: —"];
    self.ipv4Label = [self networkValueLabel:@"IPv4: —"];
    self.ipv6Label = [self networkValueLabel:@"IPv6: —"];
    self.publicIPLabel = [self networkValueLabel:@"IP công khai: Chưa đo"];
    self.latencyLabel = [self networkValueLabel:@"Độ trễ HTTPS: Chưa đo"];
    self.updatedLabel = [self networkValueLabel:@"Chưa cập nhật"];
    for (UILabel *label in @[self.networkNameLabel, self.interfaceLabel, self.ipv4Label, self.ipv6Label, self.publicIPLabel, self.latencyLabel, self.updatedLabel]) {
        [connectionCard addArrangedSubview:label];
    }

    UIStackView *actions = [self newCardWithTitle:@"THAO TÁC" subtitle:@"Làm mới thông tin và kiểm tra độ trễ kết nối."];
    [actions addArrangedSubview:PMMediaButton(@"Làm mới mạng", @selector(refreshNetworkInfo), self)];
    [actions addArrangedSubview:PMMediaButton(@"Cho phép đọc tên Wi‑Fi", @selector(requestWiFiNamePermission), self)];
    [self addNote:@"iOS có thể ẩn SSID nếu chưa cấp quyền vị trí khi dùng hoặc thiếu quyền Access Wi‑Fi Information. Trang Mạng không dùng tọa độ; trang Trái đất chỉ đọc vị trí khi bạn chủ động nhấn nút Lấy vị trí thiết bị. IP nội bộ và tên Wi‑Fi chỉ hiển thị trên thiết bị; để lấy IP công khai và đo độ trễ, ứng dụng gửi một yêu cầu HTTPS tới 1.1.1.1 nên máy chủ đó có thể nhìn thấy IP công khai của kết nối. Độ trễ này không phải ICMP ping thuần." toStack:self.contentStack];
    self.locationManager = [CLLocationManager new];
    self.locationManager.delegate = self;
    NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
    [center addObserver:self selector:@selector(applicationWillResignActive:) name:UIApplicationWillResignActiveNotification object:nil];
    [center addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (UILabel *)networkValueLabel:(NSString *)text {
    UILabel *label = [UILabel new];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = UIColor.labelColor;
    label.font = [UIFont monospacedSystemFontOfSize:13.0 weight:UIFontWeightMedium];
    label.numberOfLines = 0;
    label.adjustsFontSizeToFitWidth = YES;
    label.minimumScaleFactor = 0.75;
    return label;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self startNetworkUpdates];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self refreshNetworkInfo];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self stopNetworkUpdates];
    [super viewWillDisappear:animated];
}

- (void)startNetworkUpdates {
    if (self.refreshTimer) return;
    [self refreshNetworkInfo];
    self.refreshTimer = [NSTimer timerWithTimeInterval:20.0 target:self selector:@selector(refreshNetworkInfo) userInfo:nil repeats:YES];
    [NSRunLoop.mainRunLoop addTimer:self.refreshTimer forMode:NSRunLoopCommonModes];
}

- (void)stopNetworkUpdates {
    [self.refreshTimer invalidate];
    self.refreshTimer = nil;
    [self.latencyTask cancel];
    self.latencyTask = nil;
    self.refreshInProgress = NO;
}

- (void)applicationWillResignActive:(NSNotification *)note {
    (void)note;
    [self stopNetworkUpdates];
}

- (void)applicationDidBecomeActive:(NSNotification *)note {
    (void)note;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (self.isViewLoaded && self.view.window && self.tabBarController.selectedViewController == self.navigationController) {
            [self startNetworkUpdates];
            [self refreshNetworkInfo];
        }
    });
}

- (void)refreshNetworkInfo {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self refreshNetworkInfo]; });
        return;
    }
    if (self.refreshInProgress || !self.isViewLoaded || !self.view.window) return;
    self.refreshInProgress = YES;
    CLAuthorizationStatus authorization = CLLocationManager.authorizationStatus;
    BOOL canReadSSID = (authorization == kCLAuthorizationStatusAuthorizedAlways || authorization == kCLAuthorizationStatusAuthorizedWhenInUse);
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSDictionary *interfaces = PMReadNetworkInterfaces();
        NSString *ssid = canReadSSID ? PMReadCurrentWiFiSSID() : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            self.refreshInProgress = NO;
            if (!self.isViewLoaded || !self.view.window) return;
            NSString *kind = interfaces[@"Kind"] ?: @"Không xác định";
            NSString *name = interfaces[@"Interface"] ?: @"—";
            BOOL isWiFi = [name isEqualToString:@"en0"] || [name isEqualToString:@"en1"];
            NSString *networkName = ssid.length ? ssid :
                (isWiFi ? (canReadSSID ? @"SSID bị iOS ẩn / thiếu quyền Wi‑Fi" : @"Cần quyền vị trí khi dùng để đọc SSID") :
                 ([name hasPrefix:@"pdp"] ? @"Mạng di động" : @"Không có SSID trên giao diện này"));
            self.networkNameLabel.text = [NSString stringWithFormat:@"Tên mạng: %@", networkName];
            self.interfaceLabel.text = [NSString stringWithFormat:@"Loại mạng: %@ (%@)", kind, name];
            self.ipv4Label.text = [NSString stringWithFormat:@"IPv4: %@", interfaces[@"IPv4"] ?: @"Không khả dụng"];
            self.ipv6Label.text = [NSString stringWithFormat:@"IPv6: %@", interfaces[@"IPv6"] ?: @"Không khả dụng"];
            self.updatedLabel.text = [NSString stringWithFormat:@"Cập nhật: %@", [NSDateFormatter localizedStringFromDate:NSDate.date dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle]];
            [self startLatencyProbe];
        });
    });
}

- (void)startLatencyProbe {
    [self.latencyTask cancel];
    self.latencyTask = nil;
    NSURL *url = [NSURL URLWithString:@"https://1.1.1.1/cdn-cgi/trace"];
    if (!url) return;
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:6.0];
    request.HTTPMethod = @"GET";
    request.HTTPShouldHandleCookies = NO;
    NSTimeInterval start = NSProcessInfo.processInfo.systemUptime;
    __weak typeof(self) weakSelf = self;
    self.latencyTask = [NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(__unused NSData *data, NSURLResponse *response, NSError *error) {
        NSTimeInterval elapsed = (NSProcessInfo.processInfo.systemUptime - start) * 1000.0;
        NSString *publicAddress = nil;
        if (data.length > 0) {
            NSString *body = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            for (NSString *line in [body componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
                if ([line hasPrefix:@"ip="] && line.length > 3) { publicAddress = [line substringFromIndex:3]; break; }
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) self = weakSelf;
            if (!self || !self.isViewLoaded || !self.view.window) return;
            if (error || ![response isKindOfClass:[NSHTTPURLResponse class]]) {
                self.latencyLabel.text = [NSString stringWithFormat:@"Độ trễ HTTPS: Không đo được (%@)", error.localizedDescription ?: @"không có phản hồi"];
                self.publicIPLabel.text = @"IP công khai: Không lấy được";
            } else {
                NSInteger status = ((NSHTTPURLResponse *)response).statusCode;
                self.latencyLabel.text = [NSString stringWithFormat:@"Độ trễ HTTPS tới 1.1.1.1: %.0f ms · HTTP %ld", elapsed, (long)status];
                self.publicIPLabel.text = [NSString stringWithFormat:@"IP công khai: %@", publicAddress ?: @"Endpoint không trả IP"];
            }
        });
    }];
    [self.latencyTask resume];
}

- (void)requestWiFiNamePermission {
    CLAuthorizationStatus status = CLLocationManager.authorizationStatus;
    if (status == kCLAuthorizationStatusNotDetermined) {
        self.locationPermissionRequested = YES;
        [self.locationManager requestWhenInUseAuthorization];
    } else if (status == kCLAuthorizationStatusAuthorizedAlways || status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        [self refreshNetworkInfo];
    } else {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Chưa được cấp quyền Wi‑Fi" message:@"Hãy bật quyền Vị trí khi dùng trong Cài đặt iOS. Trang Mạng cần trạng thái quyền để đọc SSID khi iOS cho phép; trang Trái đất chỉ đọc tọa độ sau khi bạn chủ động nhấn nút lấy vị trí." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"Đóng" style:UIAlertActionStyleCancel handler:nil]];
        [alert addAction:[UIAlertAction actionWithTitle:@"Mở Cài đặt" style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            NSURL *settingsURL = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if (settingsURL && [UIApplication.sharedApplication canOpenURL:settingsURL]) [UIApplication.sharedApplication openURL:settingsURL options:@{} completionHandler:nil];
        }]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)locationManagerDidChangeAuthorization:(CLLocationManager *)manager {
    (void)manager;
    if (self.locationPermissionRequested) {
        self.locationPermissionRequested = NO;
        [self refreshNetworkInfo];
    }
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    (void)manager; (void)status;
    if (self.locationPermissionRequested) {
        self.locationPermissionRequested = NO;
        [self refreshNetworkInfo];
    }
}

- (void)dealloc {
    [self stopNetworkUpdates];
    self.locationManager.delegate = nil;
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

@end
