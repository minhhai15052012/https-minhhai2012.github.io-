#import "PMBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PMEarthViewController : PMBaseViewController
@end

@interface PMNetworkViewController : PMBaseViewController
@end

NS_ASSUME_NONNULL_END
