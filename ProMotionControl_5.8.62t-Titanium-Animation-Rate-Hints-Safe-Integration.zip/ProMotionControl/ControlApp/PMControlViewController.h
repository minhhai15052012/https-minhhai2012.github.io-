#import <UIKit/UIKit.h>
#import "PMBaseViewController.h"

void PMInstallAppLocalization(void);

@interface PMControlViewController : PMBaseViewController
+ (UIViewController *)makeAppRootController;
@end
