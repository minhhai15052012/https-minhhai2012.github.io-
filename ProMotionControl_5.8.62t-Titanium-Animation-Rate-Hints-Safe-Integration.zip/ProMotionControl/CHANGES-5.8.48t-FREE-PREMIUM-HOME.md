# ProMotion Control 5.8.48t — FREE/PREMIUM Home and live metrics

## Home
- Add a FREE / PREMIUM selector at the top of the Home page.
- FREE remains the standard dashboard. PREMIUM is a session-only local UI gate; it is not remote server authentication.
- Selecting PREMIUM requests the configured local password before showing the Premium preset section.
- Keep the Home page's two primary groups: THÔNG SỐ and CÔNG TẮC.
- Show three separate horizontal metric cards: selected FPS target, selected Hz target, and system CPU load.
- Retain the CPU waveform and sample/update the dashboard every 0.2 seconds while the Home page is visible.
- Keep the Hz and FPS sliders in the 10–244 requested-value range.
- Remove the separate UI-rendered FPS/max-display-rate readout.
- Keep all 16 existing global switches in the Home switch board.

## Apps
- Preserve the LaunchServices application catalogue and add best-effort app icon loading from each retained application proxy.
- Decode icons on a dedicated serial utility queue and update image views on the main queue.
- Fall back to the generic app symbol when the private icon selector is unavailable or restricted.

## Performance / About
- Remove the CPU/GPU overview card and chip-information summary card from Advanced Performance.
- Remove the obsolete 15-second overview check from the About utilities. The safe cache cleanup only targets this app's own cache/tmp directories.
- Keep the 3-second typewriter intro, author/version/iOS information, community links, and safe Respring notice.

## Premium presets
- Add balanced, low-latency, and battery-focused presets that coordinate existing preference keys while retaining thermal and compatibility safeguards.
- Presets do not overclock CPU/GPU and do not promise a 5x performance increase.
- Presets write configuration only. Cross-app runtime intervention remains fail-closed in Tweak.x for this crash-containment build.

## Build and safety notes
- Keep the supplied PMFrameOptimizer class verbatim in Tweak.x; it remains compiled but intentionally not started in the crash-containment release.
- Keep PMRuntimeHooksAllowedForEmergencyRelease() returning NO and the strict control-app-only filter. Do not describe saved settings as active in other apps.
- The supplied PMRootHelper snippet is not included: setuid/seteuid attempts to elevate an app process and popen(command) executes caller-provided shell commands with root privileges. The app has no safe, general-purpose reason to expose that interface. No arbitrary root command runner is shipped.
- VERSION remains 5.8.47t in source; run-build-ubuntu.sh stamps 5.8.48t after a successful build and rolls back stamped files after a failed build.

## Validation
- Shell syntax, plist structure, source-level dashboard preflight, and ZIP integrity are checked before packaging.
- A full Theos/iOS SDK compile and device runtime test still must be performed in the user's Ubuntu/WSL and test device environment.
