# Build validation fix — target 5.8.46t

The previous Theos run successfully compiled both tweak slices, linked the app, staged the package, and generated a .deb. The wrapper then rejected the staged app because `ControlApp/Resources/Info.plist` contained `CFBundleDisplayName = ProMotionControl`, while the package validator requires `ProMotion Control`.

Changes in this hotfix:
- Set `CFBundleDisplayName` to the exact expected value `ProMotion Control`.
- Add the same display-name assertion to the early preflight so a metadata mismatch is caught before compiling or mutating version stamps.
- Remove the unused `PMIsAllowedAppProcess` helper that generated a compiler warning.
- Remove the unused UIKit swizzle helper and its `objc/runtime.h` import; runtime swizzling remains disabled.
- Remove one duplicate localization dictionary key; preserve the later translation that had previously taken effect.

No FPS/runtime hook behavior, app Bundle ID, executable name, app bundle name, or safety filter was changed for this validation fix.

The source VERSION remains 5.8.45t so `run-build-ubuntu.sh` increments to target package version 5.8.46t. The prior failed run rolled back the source version and removed its failed 5.8.46t package artifact as part of recovery.

Validation performed here: Bash syntax checks, Info.plist parsing and identity assertions, display-name preflight check, duplicate-key check, and unused-helper checks. Theos compilation and on-device installation were not performed in this environment.

Separate warnings from the user's log:
- The `arm64e ABI compiler` linker warning is not the cause of the display-name assertion. It indicates a toolchain/ABI compatibility concern and should be investigated separately; this hotfix does not suppress it or change supported architectures.
- `no debug symbols` follows the build's `-g0` flags; it is not the failure cause.
