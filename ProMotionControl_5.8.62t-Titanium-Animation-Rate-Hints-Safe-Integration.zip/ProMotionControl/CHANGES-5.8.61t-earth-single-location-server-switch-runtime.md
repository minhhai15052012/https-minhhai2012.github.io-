# ProMotion Control 5.8.61t – Earth location bar and selected-server runtime

- Replaced the two-line location text with one compact iPhone location indicator bar. It displays latitude, longitude, and the accuracy reported by Core Location.
- Earth location uses When-In-Use authorization only. Live location updates run only while the Earth page is visible; updates stop on tab exit or app background. Location accuracy and cadence relax under Fair/Low Power thermal conditions and pause under Serious/Critical thermal pressure.
- Earth network diagnostics include public Apple connectivity endpoints alongside Cloudflare/Google connectivity endpoints. They measure HTTPS response time only; no private Apple service, satellite, carrier, modem, or routing control is attempted.
- Earth network, path and rate diagnostics refresh only in the foreground, with longer intervals during heat/Low Power Mode and automatic HTTPS probes paused at Critical thermal state.
- Centralized FREE/PREMIUM/ADMIN engine activation through `refreshActiveServerRuntime`. The master `Enabled` switch now stops all app-local engines when OFF; the selected tier's own scheduler/hook/touch switches remain authoritative. All settings subpages route changes back to the root controller immediately.
- FREE `FreeSmoothEngineEnabled` is now checked both during activation and thermal/power state changes.
- `CADisplayLink` hooks now capture the latest app-originated preferred frame-rate request for each link and restore it when the master/tier hook is disabled, screen capture blocks application, or the app enters the background. The saved server profile is reapplied when the app becomes active.
- Only one server profile runs at a time (FREE or PREMIUM or ADMIN). They share the same display-link/runtime target and are not run concurrently.
- No private driver hooks, system-wide injection, fake display modes, overclocking, thermal-throttle bypass, or indefinite background keepalive were added.

- The Earth page has exactly one location indicator bar. Its coordinate text is updated from Core Location while the page is visible and foregrounded; there is no separate accuracy row.
