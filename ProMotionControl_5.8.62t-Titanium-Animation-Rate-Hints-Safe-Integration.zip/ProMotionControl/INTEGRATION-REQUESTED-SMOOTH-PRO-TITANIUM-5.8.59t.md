# Requested Smooth / Pro / Titanium integration — 5.8.59t

## Active integration

- PREMIUM: `PMSmoothEngineAdvanced` delegates to the existing `PMAdvancedOptimizer` single `CADisplayLink`. The user's selected Hz/FPS values are retained as the requested maximum/preferred range; UIKit and the panel capability determine the effective cadence.
- ADMIN: `PMSmoothEnginePro` delegates to `TitaniumAbsoluteUnlockEngine` and the existing `PMUltimatePowerEngine` → `PMUltimateNexusEngine` → `PMPowerRefreshEngine` path. It exposes the existing monitor's last-frame timestamp and dropped-frame count; it does not create a duplicate display link.
- ADMIN Titanium adapter: preserves separate Hz and FPS requests, clamps each to the accepted 10…244 configuration domain, then the existing runtime adapter clamps to `UIScreen.maximumFramesPerSecond` and system power/thermal policy.
- The frame monitor records `lastFrameDelta`, measured callback FPS, and dropped-frame count. It throttles auxiliary monitoring work instead of deleting unrelated URL/network cache data.
- Touch tuning remains limited to the app's own scroll views and saves/restores prior settings.

## Not compiled as requested

The following parts of the supplied snippets are intentionally not activated: `SCHED_FIFO` real-time scheduling, sweeping all `UIApplication` windows/gesture recognizers, emergency `NSURLCache` deletion after frame drops, fake `CADisplay`/`UIScreen.maximumFramesPerSecond` values, private `CAWindowServerDisplay` hooks, and the SpringBoard-wide constructor/filter. These operations do not unlock the display panel or guarantee 244 Hz; they can disrupt touch routing, create more work after a hitch, misreport hardware capability, and crash or destabilize SpringBoard/WindowServer.

`Tweak.x` retains the existing exact `com.dell.promotioncontrol.app` bundle guard and the supported `CADisplayLink` request hook. No system-wide or third-party-process injection is added. The FREE engine remains unchanged.

## Build/test status

Source-level integration and archive validation only. A Theos build and on-device runtime test were not performed in this environment.
