# 5.8.61t — Titanium Governor / Three Server / ADMIN Transition Assist

## Shared governor
- Integrated `TitaniumAdaptiveGovernorEngine` into FREE, PREMIUM and ADMIN rate selection.
- It stores requested Hz/FPS separately and computes effective pacing using the device panel maximum, Low Power Mode, iOS thermal state, charging guard and the existing late-frame monitor.
- It intentionally reuses the existing tier-owned CADisplayLink/Nexus pipeline; it does not add a second permanent CADisplayLink.
- A foreground-only 10-second watchdog re-checks thermal/power/charging changes and recovers a missing selected-tier link. It stops when the app enters the background and restarts after foreground activation.

## ADMIN transition assist
- Added `AdminHomeTransitionShieldEnabled` and the `TitaniumUltimateHomeShieldEngine` helper.
- It re-applies the existing ADMIN scheduler when ProMotion Control returns to the foreground, with a 0.4-second transition window.
- It is app-local. It does not hook `SBMainWorkspace` or alter the SpringBoard Home Screen.

## Not integrated from the supplied sample
- No `KeepAlive`/launchd respawn daemon, no `FBProcess`/SIGKILL blocking, and no force-quit bypass. iOS owns process termination and this package remains app-local.
- No `SCHED_FIFO` or real-time pthread priority escalation; this can starve other work, is not a supported iOS performance control, and cannot guarantee higher refresh.
- No global `SpringBoard` hook, system-wide gesture mutation, or `NSURLCache` purge on a Home transition.
- No generic TCP socket tuning hook was added: `setsockopt` must be applied to sockets owned by the app, and the provided code has no such socket descriptor. It cannot globally lower ping.

## Verification
- Source-level integration and shell syntax are checked. A complete Theos compile and device runtime test are still required on the user's WSL/iPhone environment.
