#import <Foundation/Foundation.h>
#import "shared/AFTweakScanner.h"

#ifdef __cplusplus
extern "C" {
#endif

NS_ASSUME_NONNULL_BEGIN

/* Tập selector mà dylib tham chiếu (bảng __objc_methname), đã lọc nhiễu.
   Dùng để phát hiện hai tweak cùng nhắm vào một bề mặt API. */
NSSet<NSString *> *AFDylibSelectorSet(NSString * _Nullable dylibPath);

/* Cặp tweak có khả năng xung đột hook trong cùng tiến trình.
   Mỗi phần tử: a, b, shared (số selector trùng), selectors (tối đa 8), static=YES. */
NSArray<NSDictionary *> *AFDetectTweakConflicts(NSArray<AFTweakInfo *> *tweaks);

/* Khoá ổn định cho một cặp tweak (không phân biệt thứ tự). */
NSString *AFConflictPairKey(NSString *a, NSString *b);

/* Đọc conflict_live.txt do SpringBoard ghi: các lần IMP của method bị tweak
   khác chiếm lại. Trả về @{@"time": NSNumber, @"pairs": NSArray}. */
NSDictionary * _Nullable AFReadLiveConflictReport(void);

/* Gộp xung đột tĩnh (daemon quét dylib) và xung đột runtime trong state. */
NSArray<NSDictionary *> *AFConflictPairsFromState(NSDictionary *state);

/* Nếu base là chủ hook cũ, trả về tweak đã chiếm hook sau đó (nghi phạm hơn). */
NSString * _Nullable AFConflictPartner(NSString *base, NSDictionary *state);

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
}
#endif
