#import "shared/AFConflict.h"
#import "shared/AFCore.h"

#import <mach-o/fat.h>
#import <mach-o/loader.h>
#import <math.h>
#import <string.h>
#import <sys/stat.h>

static NSMutableDictionary<NSString *, NSDictionary *> *gSelectorCache = nil;
static NSLock *gSelectorLock = nil;

static NSLock *AFSelectorLock(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gSelectorLock = [NSLock new];
        gSelectorCache = [NSMutableDictionary dictionary];
    });
    return gSelectorLock;
}

/* Selector xuất hiện ở hầu hết tweak nên không dùng để kết luận xung đột. */
static NSSet<NSString *> *AFSelectorStoplist(void) {
    static NSSet *set;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        set = [NSSet setWithArray:@[
            @"init", @"dealloc", @"description", @"hash", @"isEqual:",
            @"layoutSubviews", @"layoutSubviews", @"viewDidLoad", @"viewWillAppear:",
            @"viewDidAppear:", @"viewWillDisappear:", @"viewDidDisappear:",
            @"setFrame:", @"frame", @"setDelegate:", @"delegate", @"setHidden:",
            @"setAlpha:", @"setBackgroundColor:", @"backgroundColor", @"setNeedsLayout",
            @"setNeedsDisplay", @"addSubview:", @"removeFromSuperview", @"superview",
            @"bounds", @"setBounds:", @"tag", @"setTag:", @"retain", @"release",
            @"autorelease", @"copy", @"mutableCopy", @"class", @"self", @"setObject:forKey:",
            @"objectForKey:", @"removeObjectForKey:", @"allKeys", @"count", @"addObject:",
            @"removeObject:", @"containsObject:", @"setValue:forKey:", @"valueForKey:",
            @"respondsToSelector:", @"isKindOfClass:", @"conformsToProtocol:",
            @"setTitle:", @"title", @"setText:", @"text", @"setImage:", @"image",
            @"setEnabled:", @"isEnabled", @"initWithFrame:", @"initWithCoder:",
            @"setNeedsStatusBarAppearanceUpdate", @"preferredStatusBarStyle",
            @"viewWillLayoutSubviews", @"viewDidLayoutSubviews", @"setNeedsUpdateOfScreenEdgesDeferringSystemGestures",
            @"applicationDidFinishLaunching:", @"applicationDidEnterBackground:",
            @"applicationWillEnterForeground:", @"applicationDidBecomeActive:",
            @"applicationWillResignActive:", @"setNeedsLayout", @"setNeedsDisplay",
            @"traitCollectionDidChange:", @"safeAreaInsets", @"setCornerRadius:",
            @"setClipsToBounds:", @"setContentMode:", @"setUserInteractionEnabled:",
            @"setTranslatesAutoresizingMaskIntoConstraints:", @"addTarget:action:forControlEvents:"
        ]];
    });
    return set;
}

static BOOL AFLooksLikeSelector(NSString *value) {
    if (value.length < 6 || value.length > 96) return NO;
    static NSCharacterSet *allowed = nil;
    static NSCharacterSet *inverted = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        allowed = [NSCharacterSet characterSetWithCharactersInString:
            @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_:+"];
        inverted = [allowed invertedSet];
    });
    if ([value rangeOfCharacterFromSet:inverted].location != NSNotFound) return NO;
    if ([value hasPrefix:@"_"]) return NO;
    if ([value hasPrefix:@"NS"] && [value hasSuffix:@"Notification"]) return NO;
    if ([AFSelectorStoplist() containsObject:value]) return NO;

    BOOL hasColon = [value containsString:@":"];
    NSRange upper = [value rangeOfCharacterFromSet:
        [NSCharacterSet uppercaseLetterCharacterSet]];
    BOOL hasUpper = upper.location != NSNotFound;
    if (!hasColon && !hasUpper) return NO;
    return YES;
}

static void AFCollectCStringSelectors(const uint8_t *bytes,
                                      NSUInteger length,
                                      NSMutableSet<NSString *> *out) {
    if (!bytes || length == 0) return;
    NSUInteger start = 0;
    for (NSUInteger i = 0; i <= length; i++) {
        if (i != length && bytes[i] != 0) continue;
        NSUInteger valueLength = i - start;
        if (valueLength >= 6 && valueLength <= 96) {
            NSString *value = [[NSString alloc] initWithBytes:bytes + start
                                                       length:valueLength
                                                     encoding:NSUTF8StringEncoding];
            if (value && AFLooksLikeSelector(value)) [out addObject:value];
        }
        start = i + 1;
    }
}

static uint32_t AFReadBE32(const uint8_t *bytes) {
    return ((uint32_t)bytes[0] << 24) | ((uint32_t)bytes[1] << 16) |
           ((uint32_t)bytes[2] << 8) | (uint32_t)bytes[3];
}

static uint32_t AFReadLE32(const uint8_t *bytes) {
    return ((uint32_t)bytes[3] << 24) | ((uint32_t)bytes[2] << 16) |
           ((uint32_t)bytes[1] << 8) | (uint32_t)bytes[0];
}

/* Dylib trên thiết bị là fat binary: tìm slice Mach-O 64-bit đầu tiên. */
static NSUInteger AFMachOSliceOffset(NSData *data) {
    if (data.length < 8) return NSNotFound;
    const uint8_t *bytes = data.bytes;
    uint32_t rawMagic = AFReadLE32(bytes);
    if (rawMagic == MH_MAGIC_64) return 0;

    uint32_t beMagic = AFReadBE32(bytes);
    if (beMagic != FAT_MAGIC && beMagic != FAT_MAGIC_64) return NSNotFound;

    BOOL is64 = (beMagic == FAT_MAGIC_64);
    uint32_t count = AFReadBE32(bytes + 4);
    if (count == 0 || count > 16) return NSNotFound;

    NSUInteger entrySize = is64 ? 32 : 20;
    for (uint32_t i = 0; i < count; i++) {
        NSUInteger entry = 8 + (NSUInteger)i * entrySize;
        if (entry + entrySize > data.length) break;
        uint64_t offset = is64 ? 0 : AFReadBE32(bytes + entry + 8);
        uint64_t size = is64 ? 0 : AFReadBE32(bytes + entry + 12);
        if (is64) {
            uint32_t high = AFReadBE32(bytes + entry + 8);
            uint32_t low = AFReadBE32(bytes + entry + 12);
            offset = ((uint64_t)high << 32) | low;
            high = AFReadBE32(bytes + entry + 16);
            low = AFReadBE32(bytes + entry + 20);
            size = ((uint64_t)high << 32) | low;
        }
        if (offset == 0 || size == 0) continue;
        if (offset + 4 > data.length) continue;
        if (offset + size > data.length) continue;
        uint32_t inner = AFReadLE32(bytes + offset);
        if (inner != MH_MAGIC_64) continue;
        return (NSUInteger)offset;
    }
    return NSNotFound;
}

static NSSet<NSString *> *AFSelectorsFromMachO(NSData *data) {
    if (data.length < sizeof(struct mach_header_64)) return [NSSet set];

    NSUInteger sliceOffset = AFMachOSliceOffset(data);
    if (sliceOffset == NSNotFound) return [NSSet set];

    const uint8_t *bytes = data.bytes;
    NSUInteger size = data.length;

    const struct mach_header_64 *header =
        (const struct mach_header_64 *)(bytes + sliceOffset);
    if (header->magic != MH_MAGIC_64) return [NSSet set];
    if (header->ncmds == 0 || header->ncmds > 4096) return [NSSet set];

    NSMutableSet<NSString *> *selectors = [NSMutableSet set];
    NSUInteger cursor = sliceOffset + sizeof(struct mach_header_64);
    NSUInteger limit = size;
    for (uint32_t i = 0; i < header->ncmds; i++) {
        if (cursor + sizeof(struct load_command) > limit) break;
        const struct load_command *command = (const struct load_command *)(bytes + cursor);
        if (command->cmdsize < sizeof(struct load_command)) break;
        if (cursor + command->cmdsize > limit) break;

        if (command->cmd == LC_SEGMENT_64) {
            const struct segment_command_64 *segment =
                (const struct segment_command_64 *)command;
            NSUInteger sectionCursor = cursor + sizeof(struct segment_command_64);
            NSUInteger segmentEnd = cursor + command->cmdsize;
            for (uint32_t s = 0; s < segment->nsects; s++) {
                if (sectionCursor + sizeof(struct section_64) > segmentEnd) break;
                const struct section_64 *section =
                    (const struct section_64 *)(bytes + sectionCursor);
                if (strncmp(section->sectname, "__objc_methname", 16) == 0 &&
                    section->size > 0 && section->offset <= size &&
                    section->size <= size - (NSUInteger)section->offset &&
                    sliceOffset + section->offset <= size &&
                    section->size <= size - (sliceOffset + (NSUInteger)section->offset)) {
                    AFCollectCStringSelectors(
                        bytes + sliceOffset + (NSUInteger)section->offset,
                        (NSUInteger)section->size, selectors);
                }
                sectionCursor += sizeof(struct section_64);
            }
        }
        cursor += command->cmdsize;
    }
    return selectors;
}

NSSet<NSString *> *AFDylibSelectorSet(NSString *dylibPath) {
    if (dylibPath.length == 0) return [NSSet set];

    NSDictionary *attributes = [[NSFileManager defaultManager]
        attributesOfItemAtPath:dylibPath error:NULL];
    NSDate *modified = attributes[NSFileModificationDate];
    double stamp = modified ? modified.timeIntervalSince1970 : 0;

    NSLock *lock = AFSelectorLock();
    [lock lock];
    NSDictionary *cached = gSelectorCache[dylibPath];
    [lock unlock];
    if (cached && fabs([cached[@"stamp"] doubleValue] - stamp) < 1.0) {
        id value = cached[@"selectors"];
        return [value isKindOfClass:[NSSet class]] ? value : [NSSet set];
    }

    NSSet<NSString *> *selectors = [NSSet set];
    @autoreleasepool {
        NSData *data = [NSData dataWithContentsOfFile:dylibPath
                                              options:NSDataReadingMappedIfSafe
                                                error:NULL];
        if (data.length > 0 && data.length <= 64 * 1024 * 1024) {
            selectors = AFSelectorsFromMachO(data);
        }
    }

    [lock lock];
    gSelectorCache[dylibPath] = @{@"stamp": @(stamp), @"selectors": selectors};
    [lock unlock];
    return selectors;
}

static NSSet<NSString *> *AFTweakTargets(AFTweakInfo *info) {
    NSMutableSet *targets = [NSMutableSet set];
    NSDictionary *plist = info.plistPath.length ? AFReadPlist(info.plistPath) : nil;
    id filter = plist[@"Filter"];
    if (![filter isKindOfClass:[NSDictionary class]]) return targets;
    for (NSString *key in @[@"Bundles", @"Executables"]) {
        id list = filter[key];
        if (![list isKindOfClass:[NSArray class]]) continue;
        for (id item in list) {
            if ([item isKindOfClass:[NSString class]] && [item length]) {
                [targets addObject:[item lowercaseString]];
            }
        }
    }
    return targets;
}

NSString *AFConflictPairKey(NSString *a, NSString *b) {
    NSString *left = [a lowercaseString] ?: @"";
    NSString *right = [b lowercaseString] ?: @"";
    if ([left compare:right] == NSOrderedDescending) {
        NSString *swap = left;
        left = right;
        right = swap;
    }
    return [NSString stringWithFormat:@"%@|%@", left, right];
}

NSArray<NSDictionary *> *AFDetectTweakConflicts(NSArray<AFTweakInfo *> *tweaks) {
    NSMutableArray<AFTweakInfo *> *items = [NSMutableArray array];
    for (AFTweakInfo *info in tweaks) {
        if (![info isKindOfClass:[AFTweakInfo class]]) continue;
        if (!info.enabled || info.base.length == 0) continue;
        if (AFIsSelfTweakBase(info.base) || AFIsWhitelistedTweakBase(info.base)) continue;
        if (info.plistPath.length == 0 || info.dylibPath.length == 0) continue;
        [items addObject:info];
        if (items.count >= 60) break;
    }
    if (items.count < 2) return @[];

    NSMutableDictionary<NSString *, NSSet<NSString *> *> *selectors =
        [NSMutableDictionary dictionary];
    NSMutableDictionary<NSString *, NSSet<NSString *> *> *targets =
        [NSMutableDictionary dictionary];
    for (AFTweakInfo *info in items) {
        NSString *key = info.base.lowercaseString;
        NSSet *set = AFDylibSelectorSet(info.dylibPath);
        if (set.count < 3) continue;
        NSSet *targetSet = AFTweakTargets(info);
        if (targetSet.count == 0) continue;
        selectors[key] = set;
        targets[key] = targetSet;
    }

    NSArray<NSString *> *keys = [selectors.allKeys sortedArrayUsingSelector:@selector(compare:)];
    NSMutableArray<NSDictionary *> *pairs = [NSMutableArray array];
    for (NSUInteger i = 0; i < keys.count; i++) {
        NSString *keyA = keys[i];
        NSSet *selectorsA = selectors[keyA];
        for (NSUInteger j = i + 1; j < keys.count; j++) {
            NSString *keyB = keys[j];
            if (![targets[keyA] intersectsSet:targets[keyB]]) continue;
            NSSet *selectorsB = selectors[keyB];
            NSUInteger smaller = MIN(selectorsA.count, selectorsB.count);
            if (smaller < 3) continue;

            NSMutableSet *shared = [NSMutableSet setWithSet:selectorsA];
            [shared intersectSet:selectorsB];
            if (shared.count < 3) continue;
            double ratio = (double)shared.count / (double)smaller;
            if (ratio < 0.15) continue;

            NSArray<NSString *> *sample = [[shared allObjects]
                sortedArrayUsingSelector:@selector(compare:)];
            if (sample.count > 8) {
                sample = [sample subarrayWithRange:NSMakeRange(0, 8)];
            }
            [pairs addObject:@{
                @"a": keyA,
                @"b": keyB,
                @"shared": @(shared.count),
                @"selectors": sample,
                @"static": @YES,
                @"score": @((double)shared.count * ratio)
            }];
        }
    }

    [pairs sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        double scoreA = [a[@"score"] doubleValue];
        double scoreB = [b[@"score"] doubleValue];
        if (scoreA == scoreB) {
            return [a[@"a"] compare:b[@"a"]];
        }
        return scoreA > scoreB ? NSOrderedAscending : NSOrderedDescending;
    }];
    if (pairs.count > 25) pairs = [[pairs subarrayWithRange:NSMakeRange(0, 25)] mutableCopy];
    return pairs;
}

NSDictionary *AFReadLiveConflictReport(void) {
    NSString *path = AFConflictMarkerPath();
    NSString *text = [NSString stringWithContentsOfFile:path
                                               encoding:NSUTF8StringEncoding error:NULL];
    if (text.length == 0) return nil;

    NSMutableDictionary *report = [NSMutableDictionary dictionary];
    NSMutableArray<NSDictionary *> *pairs = [NSMutableArray array];
    NSArray<NSString *> *lines = [text componentsSeparatedByCharactersInSet:
                                  [NSCharacterSet newlineCharacterSet]];
    for (NSString *rawLine in lines) {
        NSString *line = [rawLine stringByTrimmingCharactersInSet:
                          [NSCharacterSet whitespaceCharacterSet]];
        if ([line hasPrefix:@"time="]) {
            report[@"time"] = @([line substringFromIndex:5].doubleValue);
        } else if ([line hasPrefix:@"pair="]) {
            NSString *body = [line substringFromIndex:5];
            NSArray<NSString *> *parts = [body componentsSeparatedByString:@"|"];
            if (parts.count < 2) continue;
            NSString *a = parts[0];
            NSString *b = parts[1];
            if (!a.length || !b.length) continue;
            if (AFIsSelfTweakBase(a) || AFIsSelfTweakBase(b)) continue;
            NSString *methodsText = parts.count > 2 ? parts[2] : @"";
            NSArray<NSString *> *methods = methodsText.length
                ? [methodsText componentsSeparatedByString:@";"] : @[];
            if (methods.count > 12) {
                methods = [methods subarrayWithRange:NSMakeRange(0, 12)];
            }
            [pairs addObject:@{
                @"a": a,
                @"b": b,
                @"shared": @(methods.count),
                @"selectors": methods,
                @"static": @NO
            }];
            if (pairs.count >= 40) break;
        }
    }
    if (pairs.count == 0) return nil;
    report[@"pairs"] = pairs;
    if (!report[@"time"]) report[@"time"] = @(AFNow());
    return report;
}

NSArray<NSDictionary *> *AFConflictPairsFromState(NSDictionary *state) {
    NSMutableArray<NSDictionary *> *result = [NSMutableArray array];
    NSMutableSet<NSString *> *seen = [NSMutableSet set];

    id conflicts = state[@"conflicts"];
    NSArray *pairs = [conflicts isKindOfClass:[NSDictionary class]]
        ? conflicts[@"pairs"] : nil;
    if ([pairs isKindOfClass:[NSArray class]]) {
        for (NSDictionary *pair in pairs) {
            if (![pair isKindOfClass:[NSDictionary class]]) continue;
            NSString *a = pair[@"a"];
            NSString *b = pair[@"b"];
            if (![a isKindOfClass:[NSString class]] ||
                ![b isKindOfClass:[NSString class]]) continue;
            NSString *key = AFConflictPairKey(a, b);
            if ([seen containsObject:key]) continue;
            [seen addObject:key];
            [result addObject:pair];
        }
    }
    return result;
}

NSString *AFConflictPartner(NSString *base, NSDictionary *state) {
    if (![base isKindOfClass:[NSString class]] || base.length == 0) return nil;
    for (NSDictionary *pair in AFConflictPairsFromState(state)) {
        if ([pair[@"static"] boolValue]) continue;
        NSString *a = pair[@"a"];
        NSString *b = pair[@"b"];
        if (![a isKindOfClass:[NSString class]] ||
            ![b isKindOfClass:[NSString class]]) continue;
        if ([a caseInsensitiveCompare:base] == NSOrderedSame && b.length) return b;
    }
    return nil;
}
