#import <Foundation/Foundation.h>

#ifdef __cplusplus
extern "C" {
#endif

NS_ASSUME_NONNULL_BEGIN

/* Theo dõi method nào đang bị tweak nào chiếm IMP. Khi một method đổi chủ
   (tweak B hook đè lên hook của tweak A), Auto Fix ghi conflict_live.txt để
   daemon biết cặp xung đột và ưu tiên đúng nghi phạm khi có sự cố. */
void AFStartConflictGuard(void);

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
}
#endif
