#import "tweak/AFConflictGuard.h"
#import "tweak/AFCrashGuard.h"
#import "shared/AFCore.h"
#import "shared/AFConflict.h"

#import <objc/runtime.h>
#import <mach-o/dyld.h>
#import <string.h>
#import <sys/stat.h>
#import <time.h>

static dispatch_source_t gConflictTimer = nil;
static dispatch_queue_t gConflictQueue = nil;

static Class __unsafe_unretained *gClassList = NULL;
static NSUInteger gClassCount = 0;
static NSUInteger gClassCursor = 0;

static NSMutableDictionary<NSString *, NSString *> *gMethodOwners = nil;
static NSMutableDictionary<NSString *, NSNumber *> *gOwnerCounts = nil;
static NSMutableDictionary<NSString *, NSMutableDictionary *> *gConflicts = nil;

static NSString *AFMethodOwnersKey(NSString *_Nullable path,
                                   BOOL isMeta,
                                   NSString *className,
                                   NSString *selector) {
    (void)path;
    return [NSString stringWithFormat:@"%@%@::%@", isMeta ? @"+" : @"-",
            className, selector];
}

static BOOL AFWantedClassName(const char *name) {
    if (!name || !*name) return NO;
    static const char *prefixes[] = {
        "SB", "SpringBoard", "UI", "CAM", "AVCapture", "AV", "CA", "MT", "FB",
        "LS", "NC", "BBS", "PB", "PH", "MP", "SF", "TK", "XD", "AX", "PLCamera",
        "PL", "PU", "MR", "WK", "CK", "IM", "NSStatus", "NSWindow", "NSText",
        NULL
    };
    for (size_t i = 0; prefixes[i]; i++) {
        if (strncmp(name, prefixes[i], strlen(prefixes[i])) == 0) return YES;
    }
    return NO;
}

static NSUInteger AFBuildClassList(void) {
    int count = objc_getClassList(NULL, 0);
    if (count <= 0) return 0;

    Class __unsafe_unretained *buffer =
        (__unsafe_unretained Class *)calloc((size_t)count, sizeof(Class));
    if (!buffer) return 0;
    count = objc_getClassList(buffer, count);
    if (count <= 0) {
        free(buffer);
        return 0;
    }

    Class __unsafe_unretained *filtered =
        (__unsafe_unretained Class *)calloc((size_t)count, sizeof(Class));
    if (!filtered) {
        free(buffer);
        return 0;
    }
    NSUInteger used = 0;
    for (int i = 0; i < count; i++) {
        Class cls = buffer[i];
        if (!cls) continue;
        const char *name = class_getName(cls);
        if (!AFWantedClassName(name)) continue;
        filtered[used++] = cls;
    }
    free(buffer);
    gClassList = filtered;
    gClassCount = used;
    return used;
}

static void AFNoteOwner(NSString *key, NSString *base, NSString *displayName) {
    NSString *previous = gMethodOwners[key];
    if (previous.length == 0) {
        if (gMethodOwners.count < 40000) {
            gMethodOwners[key] = base;
            gOwnerCounts[base] = @([gOwnerCounts[base] unsignedIntegerValue] + 1);
        }
        return;
    }
    if ([previous caseInsensitiveCompare:base] == NSOrderedSame) return;

    NSString *pairKey = AFConflictPairKey(previous, base);
    NSMutableDictionary *record = gConflicts[pairKey];
    if (!record) {
        record = [NSMutableDictionary dictionary];
        record[@"a"] = previous;
        record[@"b"] = base;
        record[@"methods"] = [NSMutableSet set];
        gConflicts[pairKey] = record;
    }
    if ([record[@"b"] caseInsensitiveCompare:base] != NSOrderedSame) {
        record[@"b"] = base;
    }
    NSMutableSet *methods = record[@"methods"];
    if (methods.count < 200) [methods addObject:displayName];
    gMethodOwners[key] = base;

    AFLog(@"Xung đột hook: %@ giành %@ từ %@", base, displayName, previous);
}

static void AFScanClass(Class cls) {
    if (!cls) return;
    NSString *className = NSStringFromClass(cls);
    if (className.length == 0) return;

    for (int meta = 0; meta <= 1; meta++) {
        Class target = meta ? object_getClass(cls) : cls;
        if (!target) continue;
        unsigned int count = 0;
        Method *methods = class_copyMethodList(target, &count);
        if (!methods) continue;

        for (unsigned int i = 0; i < count && i < 4000; i++) {
            Method method = methods[i];
            if (!method) continue;
            IMP imp = method_getImplementation(method);
            if (!imp) continue;

            NSString *image = AFImagePathForAddress((uint64_t)(uintptr_t)imp);
            if (image.length == 0 || !AFIsTweakImagePath(image)) continue;

            NSString *base = AFBaseFromTweakFileName(image.lastPathComponent);
            if (base.length == 0) continue;
            if (AFIsSelfTweakBase(base) || AFIsWhitelistedTweakBase(base)) continue;

            NSString *selector = NSStringFromSelector(method_getName(method));
            if (selector.length == 0) continue;

            NSString *key = AFMethodOwnersKey(image, meta != 0, className, selector);
            NSString *name = [NSString stringWithFormat:@"%@%@::%@",
                              meta ? @"+" : @"-", className, selector];
            AFNoteOwner(key, base, name);
        }
        free(methods);
    }
}

static void AFConflictWriteReports(void) {
    @autoreleasepool {
        NSMutableArray<NSString *> *bases = [[gOwnerCounts allKeys] mutableCopy];
        [bases sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            NSUInteger countA = [gOwnerCounts[a] unsignedIntegerValue];
            NSUInteger countB = [gOwnerCounts[b] unsignedIntegerValue];
            if (countA == countB) return [a compare:b];
            return countA > countB ? NSOrderedAscending : NSOrderedDescending;
        }];

        NSMutableString *hookText = [NSMutableString string];
        [hookText appendFormat:@"time=%lld\n", (long long)time(NULL)];
        [hookText appendFormat:@"proc=%@\n", [NSProcessInfo processInfo].processName ?: @""];
        [hookText appendFormat:@"classes=%lu\n", (unsigned long)gClassCount];
        for (NSString *base in bases) {
            [hookText appendFormat:@"%@=%lu\n", base,
             (unsigned long)[gOwnerCounts[base] unsignedIntegerValue]];
        }
        [hookText writeToFile:AFHookMapPath() atomically:YES
                     encoding:NSUTF8StringEncoding error:NULL];
        chmod(AFHookMapPath().fileSystemRepresentation, 0644);

        if (gConflicts.count == 0) {
            [[NSFileManager defaultManager] removeItemAtPath:AFConflictMarkerPath()
                                                       error:NULL];
            return;
        }

        NSMutableArray<NSString *> *pairKeys = [[gConflicts allKeys] mutableCopy];
        [pairKeys sortUsingSelector:@selector(compare:)];
        NSMutableString *text = [NSMutableString string];
        [text appendFormat:@"time=%lld\n", (long long)time(NULL)];
        [text appendFormat:@"proc=%@\n", [NSProcessInfo processInfo].processName ?: @""];

        NSUInteger written = 0;
        for (NSString *pairKey in pairKeys) {
            if (written >= 40) break;
            NSDictionary *record = gConflicts[pairKey];
            NSString *a = record[@"a"];
            NSString *b = record[@"b"];
            if (![a isKindOfClass:[NSString class]] ||
                ![b isKindOfClass:[NSString class]]) continue;
            NSMutableArray<NSString *> *methods =
                [[record[@"methods"] allObjects] mutableCopy];
            if (methods.count == 0) continue;
            [methods sortUsingSelector:@selector(compare:)];
            if (methods.count > 12) {
                methods = [[methods subarrayWithRange:NSMakeRange(0, 12)] mutableCopy];
            }
            [text appendFormat:@"pair=%@|%@|%@\n", a, b,
             [methods componentsJoinedByString:@";"]];
            written++;
        }

        if (written == 0) return;
        NSString *path = AFConflictMarkerPath();
        [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        chmod(path.fileSystemRepresentation, 0644);
        AFLog(@"Đã ghi %lu cặp xung đột hook vào %@", (unsigned long)written, path);
    }
}

static void AFConflictScanTick(void) {
    @autoreleasepool {
        if (gClassCount == 0) {
            if (AFBuildClassList() == 0) return;
        }

        NSUInteger budget = 150;
        while (budget-- > 0 && gClassCursor < gClassCount) {
            AFScanClass(gClassList[gClassCursor]);
            gClassCursor++;
        }

        if (gClassCursor >= gClassCount) {
            gClassCursor = 0;
            AFConflictWriteReports();
        }
    }
}

void AFStartConflictGuard(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gMethodOwners = [NSMutableDictionary dictionary];
        gOwnerCounts = [NSMutableDictionary dictionary];
        gConflicts = [NSMutableDictionary dictionary];

        NSDictionary *config = AFLoadConfig();
        double interval = [config[@"conflictScanSeconds"] doubleValue];
        if (interval < 0.5) interval = 1.0;
        if (interval > 10.0) interval = 10.0;

        gConflictQueue = dispatch_queue_create(
            "com.minhhai.autofixtweak.conflict", DISPATCH_QUEUE_SERIAL);
        dispatch_set_target_queue(gConflictQueue,
            dispatch_get_global_queue(QOS_CLASS_UTILITY, 0));

        gConflictTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,
                                                gConflictQueue);
        dispatch_source_set_timer(gConflictTimer,
            dispatch_time(DISPATCH_TIME_NOW, 4 * NSEC_PER_SEC),
            (uint64_t)(interval * NSEC_PER_SEC), NSEC_PER_SEC);
        dispatch_source_set_event_handler(gConflictTimer, ^{
            AFConflictScanTick();
        });
        dispatch_resume(gConflictTimer);

        AFLog(@"Bộ phát hiện xung đột tweak đã bật (quét %0.1fs/nhịp)", interval);
    });
}
